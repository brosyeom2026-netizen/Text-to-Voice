# Text to Voice

An Android app that converts typed English or Khmer text into speech using the phone's installed Android Text-to-Speech engine.

## Features
- English and Khmer language selection
- Available installed voice selection
- Speech playback
- Adjustable speech speed
- Save generated speech as WAV audio using Android's file picker

## Important Khmer note
Khmer speech works only if the Text-to-Speech engine installed on the device provides a Khmer voice. Availability differs by phone and engine. Check Android Settings > Languages & input > Text-to-speech output, and install a Khmer-capable engine/voice if one is available.

## Build
Open this project in Android Studio or build it with Gradle and Android SDK (API 35). Application ID: `com.texttovoice.app`.
