plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.texttovoice.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.texttovoice.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
