package com.texttovoice.app

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var languageSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private var ready = false
    private var selectedLocale: Locale = Locale.US
    private var voices: List<android.speech.tts.Voice> = emptyList()
    private var pendingOutput: File? = null
    private var pendingSaveUri: Uri? = null
    private var speed = 1.0f
    private val blue = Color.rgb(25, 102, 210)
    private val pale = Color.rgb(235, 243, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = blue
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        tts = TextToSpeech(this, this)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 250, 255))
            setPadding(dp(20), dp(22), dp(20), dp(16))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "Text to Voice"
            textSize = 28f
            setTextColor(blue)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(title)
        content.addView(label("Turn your words into speech"))
        content.addView(space(18))
        content.addView(label("Language"))
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "Khmer (ខ្មែរ)"))
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedLocale = if (position == 0) Locale.US else Locale("km", "KH")
                refreshVoices()
            }
        }
        content.addView(languageSpinner)
        content.addView(space(12))
        content.addView(label("Voice (if available)"))
        voiceSpinner = Spinner(this)
        content.addView(voiceSpinner)
        content.addView(space(12))
        content.addView(label("Your text"))
        textInput = EditText(this).apply {
            hint = "Type or paste your text here..."
            minLines = 6
            gravity = Gravity.TOP
            textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        content.addView(textInput, LinearLayout.LayoutParams(-1, dp(170)))
        content.addView(space(14))
        speedLabel = label("Speaking speed: 1.0x")
        content.addView(speedLabel)
        val speedBar = SeekBar(this).apply {
            max = 15
            progress = 5
        }
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = 0.5f + progress * 0.1f
                speedLabel.text = "Speaking speed: %.1fx".format(speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        content.addView(speedBar)
        content.addView(space(16))
        val preview = button("▶  Play voice")
        preview.setOnClickListener { speakText() }
        content.addView(preview)
        content.addView(space(10))
        val stop = button("■  Stop")
        stop.setOnClickListener { if (ready) tts.stop(); setStatus("Playback stopped.") }
        content.addView(stop)
        content.addView(space(10))
        val save = button("⬇  Save audio")
        save.setOnClickListener { saveAudio() }
        content.addView(save)
        content.addView(space(14))
        status = TextView(this).apply {
            text = "Preparing speech engine..."
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        content.addView(status)
        content.addView(space(18))
        content.addView(TextView(this).apply {
            text = "Note: Khmer speech depends on whether a Khmer voice is installed on your phone. If unavailable, install a TTS engine/voice that supports Khmer in Android settings."
            textSize = 12f
            setTextColor(Color.GRAY)
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 15f; setTextColor(Color.rgb(45, 57, 75))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun button(value: String) = Button(this).apply {
        text = value
        textSize = 16f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(blue)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(s: String) { runOnUiThread { status.text = s } }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { setStatus("Creating audio...") }
                override fun onDone(utteranceId: String?) {
                    val file = pendingOutput
                    val uri = pendingSaveUri
                    if (file != null && uri != null) {
                        try {
                            contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                            setStatus("Audio saved successfully.")
                        } catch (e: Exception) { setStatus("Could not save audio: ${e.message}") }
                        pendingOutput = null
                        pendingSaveUri = null
                    } else setStatus("Finished.")
                }
                override fun onError(utteranceId: String?) { setStatus("Speech generation failed. Check the selected language voice.") }
            })
            setStatus("Ready. Enter text to begin.")
            refreshVoices()
        } else setStatus("Text-to-speech engine could not start.")
    }

    private fun refreshVoices() {
        if (!ready) return
        val all = tts.voices?.toList() ?: emptyList()
        voices = all.filter { it.locale.language == selectedLocale.language }.sortedBy { it.name }
        val names = if (voices.isEmpty()) listOf("Default voice (if supported)") else voices.map { it.name }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val availability = tts.isLanguageAvailable(selectedLocale)
        if (availability < TextToSpeech.LANG_AVAILABLE) {
            setStatus(if (selectedLocale.language == "km") "Khmer voice is not installed on this phone." else "English voice is not available.")
        } else {
            tts.language = selectedLocale
            setStatus("Ready. ${names.size} voice option(s) found.")
        }
    }

    private fun applyVoiceAndSpeed(): Boolean {
        if (!ready) { setStatus("Speech engine is still starting."); return false }
        val result = tts.setLanguage(selectedLocale)
        if (result < TextToSpeech.LANG_AVAILABLE) {
            setStatus("This language voice is not installed. Check Android Text-to-speech settings.")
            return false
        }
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            tts.voice = voices[voiceSpinner.selectedItemPosition]
        }
        tts.setSpeechRate(speed)
        return true
    }

    private fun speakText() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        pendingOutput = null
        pendingSaveUri = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview-${UUID.randomUUID()}")
        setStatus("Speaking...")
    }

    private fun saveAudio() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        val uriIntent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "TextToVoice-${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(uriIntent, 44)
    }

    @Deprecated("Deprecated in Android API, retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            val text = textInput.text.toString().trim()
            if (text.isEmpty() || !applyVoiceAndSpeed()) return
            val out = File(cacheDir, "speech-${System.currentTimeMillis()}.wav")
            pendingOutput = out
            pendingSaveUri = data.data
            val params = Bundle().apply { putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "save-${UUID.randomUUID()}") }
            val result = tts.synthesizeToFile(text, params, out, params.getString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID))
            if (result != TextToSpeech.SUCCESS) {
                pendingOutput = null; pendingSaveUri = null
                setStatus("Could not create audio with this voice.")
            } else setStatus("Generating audio file...")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
