package com.texttovoice.app

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var languageSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var countLabel: TextView
    private var ready = false
    private var selectedLocale: Locale = Locale.US
    private var voices: List<android.speech.tts.Voice> = emptyList()
    private var pendingOutput: File? = null
    private var pendingSaveUri: Uri? = null
    private var speed = 1.0f

    private val blue = Color.rgb(31, 105, 220)
    private val darkBlue = Color.rgb(20, 68, 150)
    private val ink = Color.rgb(27, 39, 58)
    private val muted = Color.rgb(105, 119, 140)
    private val page = Color.rgb(244, 247, 252)
    private val border = Color.rgb(225, 232, 242)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = page
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        tts = TextToSpeech(this, this)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            fillViewport = true
            isVerticalScrollBarEnabled = true
            setBackgroundColor(page)
        }
        val pageColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(blue, 24)
        }
        header.addView(TextView(this).apply {
            text = "TEXT TO VOICE"
            textSize = 12f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "Give your words a voice."
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(7), 0, dp(5))
        })
        header.addView(TextView(this).apply {
            text = "Write in English or Khmer, choose an installed voice, then listen or save your audio."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        pageColumn.addView(header, matchWrap())

        pageColumn.addView(sectionTitle("1. Choose your language"))
        val languageCard = card()
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "Khmer · ខ្មែរ"))
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedLocale = if (position == 0) Locale.US else Locale("km", "KH")
                refreshVoices()
            }
        }
        languageCard.addView(languageSpinner, matchWrap())
        pageColumn.addView(languageCard, matchWrap())

        pageColumn.addView(sectionTitle("2. Pick a voice"))
        val voiceCard = card()
        voiceSpinner = Spinner(this)
        voiceCard.addView(voiceSpinner, matchWrap())
        voiceCard.addView(TextView(this).apply {
            text = "Voice choices come from the speech engine installed on your phone. Voice names and male/female options vary by engine."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(8), 0, 0)
        })
        pageColumn.addView(voiceCard, matchWrap())

        pageColumn.addView(sectionTitle("3. Write your text"))
        val textCard = card()
        textInput = EditText(this).apply {
            hint = "Type or paste your English or Khmer text here…"
            minLines = 6
            maxLines = 12
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(false)
        }
        textCard.addView(textInput, LinearLayout.LayoutParams(-1, dp(170)))

        val textTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(2))
        }
        val pasteButton = Button(this).apply {
            text = "Paste"
            textSize = 13f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.rgb(232, 241, 255), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this@MainActivity)
                    if (!pasted.isNullOrEmpty()) {
                        val start = textInput.selectionStart.coerceAtLeast(0)
                        val end = textInput.selectionEnd.coerceAtLeast(0)
                        textInput.text.replace(minOf(start, end), maxOf(start, end), pasted)
                        setStatus("Text pasted from clipboard.")
                    }
                } else setStatus("Clipboard is empty.")
            }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(190, 55, 65))
            background = rounded(Color.rgb(255, 239, 240), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                textInput.text.clear()
                setStatus("Text cleared.")
            }
        }
        textTools.addView(pasteButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textTools.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        textTools.addView(clearButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textCard.addView(textTools, matchWrap())

        countLabel = TextView(this).apply {
            text = "0 characters"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        textCard.addView(countLabel, matchWrap())
        textInput.addTextChangedListener(SimpleTextWatcher { countLabel.text = "${textInput.text.length} characters" })
        pageColumn.addView(textCard, matchWrap())

        pageColumn.addView(sectionTitle("4. Speaking speed"))
        val speedCard = card()
        speedLabel = TextView(this).apply {
            text = "Normal · 1.0×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        speedCard.addView(speedLabel)
        val speedBar = SeekBar(this).apply { max = 15; progress = 5 }
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = 0.5f + progress * 0.1f
                val label = when {
                    speed < 0.9f -> "Slow"
                    speed > 1.1f -> "Fast"
                    else -> "Normal"
                }
                speedLabel.text = "$label · %.1f×".format(speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(speedBar, matchWrap())
        speedCard.addView(TextView(this).apply {
            text = "Move the slider left for slower speech or right for faster speech."
            textSize = 12f
            setTextColor(muted)
        })
        pageColumn.addView(speedCard, matchWrap())

        pageColumn.addView(sectionTitle("5. Listen and save"))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, 0)
        }
        val play = actionButton("▶   Play voice", blue)
        play.setOnClickListener { speakText() }
        actions.addView(play, matchWrap())
        val stop = actionButton("■   Stop playback", Color.rgb(76, 91, 112))
        stop.setOnClickListener {
            if (ready) tts.stop()
            setStatus("Playback stopped.")
        }
        val stopParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(stop, stopParams)
        val save = actionButton("↓   Save audio file", darkBlue)
        save.setOnClickListener { saveAudio() }
        val saveParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(save, saveParams)
        pageColumn.addView(actions)

        val statusCard = card().apply { setPadding(dp(14), dp(13), dp(14), dp(13)) }
        status = TextView(this).apply {
            text = "Starting speech engine…"
            textSize = 13f
            setTextColor(ink)
        }
        statusCard.addView(status)
        val statusParams = matchWrap().apply { topMargin = dp(16) }
        pageColumn.addView(statusCard, statusParams)

        pageColumn.addView(TextView(this).apply {
            text = "Khmer support: your phone must have a Khmer text-to-speech voice installed. If Khmer is unavailable, check Settings → Accessibility or Text-to-speech output and install a compatible voice if offered."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(3), dp(14), dp(3), 0)
        }, matchWrap())

        scroll.addView(pageColumn)
        setContentView(scroll)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ink)
        setPadding(dp(2), dp(20), dp(2), dp(9))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = rounded(Color.WHITE, 18, border)
    }

    private fun actionButton(value: String, color: Int) = Button(this).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        minHeight = dp(52)
        elevation = dp(2).toFloat()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { runOnUiThread { status.text = message } }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { setStatus("Creating your audio…") }
                override fun onDone(utteranceId: String?) {
                    val file = pendingOutput
                    val uri = pendingSaveUri
                    if (file != null && uri != null) {
                        try {
                            contentResolver.openOutputStream(uri)?.use { output ->
                                file.inputStream().use { input -> input.copyTo(output) }
                            } ?: throw IllegalStateException("Could not open destination file")
                            setStatus("Audio saved successfully.")
                        } catch (e: Exception) {
                            setStatus("Could not save audio: ${e.message ?: "unknown error"}")
                        } finally {
                            pendingOutput = null
                            pendingSaveUri = null
                        }
                    } else setStatus("Finished playing.")
                }
                override fun onError(utteranceId: String?) { setStatus("Speech failed. Please check that this language voice is installed.") }
            })
            setStatus("Speech engine ready. Enter text to begin.")
            refreshVoices()
        } else setStatus("Speech engine could not start. Check Android Text-to-speech settings.")
    }

    private fun refreshVoices() {
        if (!ready) return
        val allVoices = tts.voices?.toList() ?: emptyList()
        voices = allVoices.filter { it.locale.language == selectedLocale.language }
            .sortedWith(compareBy<android.speech.tts.Voice> { it.isNetworkConnectionRequired }.thenBy { it.name })
        val labels = if (voices.isEmpty()) {
            listOf("System default voice · no matching voice listed")
        } else {
            voices.map {
                val quality = if (it.quality >= android.speech.tts.Voice.QUALITY_HIGH) "High quality" else "Standard"
                "${it.name} · $quality"
            }
        }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val available = tts.isLanguageAvailable(selectedLocale)
        if (available < TextToSpeech.LANG_AVAILABLE) {
            setStatus(if (selectedLocale.language == "km")
                "No Khmer voice is currently available in your phone's speech engine."
            else "No English voice is currently available in your phone's speech engine.")
        } else {
            tts.language = selectedLocale
            if (voices.isNotEmpty()) tts.voice = voices.first()
            setStatus("${labels.size} voice option(s) found. Ready.")
        }
    }

    private fun applyVoiceAndSpeed(): Boolean {
        if (!ready) { setStatus("Speech engine is still starting."); return false }
        val result = tts.setLanguage(selectedLocale)
        if (result < TextToSpeech.LANG_AVAILABLE) {
            setStatus("This language voice is not installed. Check Android Text-to-speech settings.")
            return false
        }
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            tts.voice = voices[voiceSpinner.selectedItemPosition]
        }
        tts.setSpeechRate(speed)
        return true
    }

    private fun speakText() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        pendingOutput = null
        pendingSaveUri = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview-${UUID.randomUUID()}")
        setStatus("Speaking now…")
    }

    private fun saveAudio() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "TextToVoice-${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(intent, 44)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            val text = textInput.text.toString().trim()
            if (text.isEmpty() || !applyVoiceAndSpeed()) return
            val output = File(cacheDir, "speech-${System.currentTimeMillis()}.wav")
            pendingOutput = output
            pendingSaveUri = data.data
            val id = "save-${UUID.randomUUID()}"
            val params = Bundle()
            val result = tts.synthesizeToFile(text, params, output, id)
            if (result != TextToSpeech.SUCCESS) {
                pendingOutput = null
                pendingSaveUri = null
                setStatus("Could not create the audio file with this voice.")
            } else setStatus("Generating audio file…")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
