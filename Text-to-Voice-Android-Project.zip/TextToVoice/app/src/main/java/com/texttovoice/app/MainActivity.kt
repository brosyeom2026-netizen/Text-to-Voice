package com.texttovoice.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private lateinit var languageSpinner: Spinner
    private lateinit var genderSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var emotionSpinner: Spinner
    private lateinit var emotionHintLabel: TextView
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var pitchLabel: TextView
    private lateinit var pitchBar: SeekBar
    private lateinit var countLabel: TextView

    private var ready = false
    private var selectedLocale: Locale = Locale.US
    // 0 = All Voices, 1 = Female, 2 = Male
    private var selectedGenderFilter: Int = 0
    // 0 = Neutral, 1 = Happy, 2 = Sad, 3 = Angry, 4 = Calm, 5 = Excited, 6 = Serious
    private var selectedEmotionIndex: Int = 0
    private var voices: List<Voice> = emptyList()
    private var pendingSaveUri: Uri? = null
    private var speed = 1.0f
    private var pitch = 1.0f

    // Multi-chunk expressive playback queue
    private data class SpeechChunk(
        val text: String,
        val rate: Float,
        val pitch: Float,
        val pauseAfterMs: Long
    )
    private val speechQueue = ArrayDeque<SpeechChunk>()
    private val tempChunkFiles = mutableListOf<File>()
    private var isSavingMultiChunk = false

    // Secret 5-tap Admin Approval Generator trigger
    private var copyrightTapCount = 0
    private var lastCopyrightTapTime = 0L

    // Secret salt shared between Request ID and Approval Key generator
    private val approvalSecretSalt = "YEOM_BROS_TTV_PRO_2026"

    private val blue = Color.rgb(31, 105, 220)
    private val darkBlue = Color.rgb(20, 68, 150)
    private val ink = Color.rgb(27, 39, 58)
    private val muted = Color.rgb(105, 119, 140)
    private val page = Color.rgb(244, 247, 252)
    private val border = Color.rgb(225, 232, 242)

    data class EmotionPreset(
        val title: String,
        val description: String,
        val speedProgress: Int,
        val pitchOffsetSteps: Int, // Offset relative to base gender pitch!
        val sentencePauseMs: Long,
        val commaPauseMs: Long,
        val pitchSwing: Float
    )

    private val emotions = listOf(
        EmotionPreset(
            title = "Neutral · ធម្មតា",
            description = "Balanced, clear everyday speaking tone.",
            speedProgress = 5,
            pitchOffsetSteps = 0,
            sentencePauseMs = 260L,
            commaPauseMs = 120L,
            pitchSwing = 0.00f
        ),
        EmotionPreset(
            title = "Happy / Cheerful · សប្បាយរីករាយ",
            description = "Upbeat, warm, and lively inflection with higher melody.",
            speedProgress = 6,
            pitchOffsetSteps = 2,
            sentencePauseMs = 200L,
            commaPauseMs = 90L,
            pitchSwing = 0.07f
        ),
        EmotionPreset(
            title = "Sad / Emotional · កំសត់ / សោកសៅ",
            description = "Slower, softer, lower pitch with thoughtful pauses.",
            speedProgress = 3,
            pitchOffsetSteps = -2,
            sentencePauseMs = 520L,
            commaPauseMs = 250L,
            pitchSwing = -0.05f
        ),
        EmotionPreset(
            title = "Angry / Strong · ខឹង / ម៉ឺងម៉ាត់",
            description = "Fast, forceful, punchy delivery with sharp emphasis.",
            speedProgress = 7,
            pitchOffsetSteps = -1,
            sentencePauseMs = 170L,
            commaPauseMs = 80L,
            pitchSwing = 0.06f
        ),
        EmotionPreset(
            title = "Calm / Storytelling · ស្ងប់ស្ងាត់ / និទានរឿង",
            description = "Gentle, soothing narration pace ideal for stories & rain ambience.",
            speedProgress = 4,
            pitchOffsetSteps = -1,
            sentencePauseMs = 420L,
            commaPauseMs = 200L,
            pitchSwing = 0.03f
        ),
        EmotionPreset(
            title = "Excited / Energetic · រំភើប / ស្វាហាប់",
            description = "Fast, bright, high-energy promo or viral video voice.",
            speedProgress = 8,
            pitchOffsetSteps = 2,
            sentencePauseMs = 150L,
            commaPauseMs = 70L,
            pitchSwing = 0.09f
        ),
        EmotionPreset(
            title = "Serious / News · ផ្លូវការ / ព័ត៌មាន",
            description = "Steady, authoritative broadcast tone with clear phrasing.",
            speedProgress = 5,
            pitchOffsetSteps = -1,
            sentencePauseMs = 320L,
            commaPauseMs = 150L,
            pitchSwing = 0.02f
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("yeom_bros_ttv_license_v1", Context.MODE_PRIVATE)

        window.statusBarColor = page
        window.navigationBarColor = Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        if (isDeviceActivated()) {
            openMainApp()
        } else {
            showActivationGateScreen()
        }
    }

    private fun getDeviceRequestId(): String {
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEVICE"
        val digest = MessageDigest.getInstance("SHA-256").digest("REQ|$androidId".toByteArray())
        val hex = digest.take(3).joinToString("") { "%02X".format(it) }
        return "REQ-$hex"
    }

    private fun computeApprovalKey(requestId: String): String {
        val cleanReq = requestId.trim().uppercase()
        val digest = MessageDigest.getInstance("SHA-256").digest("$cleanReq|$approvalSecretSalt".toByteArray())
        val hex = digest.take(4).joinToString("") { "%02X".format(it) }
        return "KEY-$hex"
    }

    private fun isDeviceActivated(): Boolean {
        val reqId = getDeviceRequestId()
        val savedKey = prefs.getString("approved_key", "") ?: ""
        return savedKey.isNotEmpty() && savedKey == computeApprovalKey(reqId)
    }

    private fun openMainApp() {
        buildMainAppUi()
        restoreSavedUserWork()
        if (!::tts.isInitialized) {
            tts = TextToSpeech(this, this)
        } else if (ready) {
            refreshVoices()
        }
    }

    // ==================== ACTIVATION GATE SCREEN ====================
    private fun showActivationGateScreen() {
        val requestId = getDeviceRequestId()

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(page)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }

        val brandCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = rounded(blue, 24)
        }
        brandCard.addView(TextView(this).apply {
            text = "TEXT TO VOICE · PRO VERSION"
            textSize = 11f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        })
        brandCard.addView(TextView(this).apply {
            text = "Admin Approval Required"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        })
        brandCard.addView(TextView(this).apply {
            text = "Send your Request ID to Admin to receive your Approval Code and unlock the app."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        root.addView(brandCard, matchWrap())

        val gateCard = card().apply {
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }

        gateCard.addView(TextView(this).apply {
            text = "Your Request ID"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })

        val reqBox = TextView(this).apply {
            text = requestId
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(232, 241, 255), 14, border)
        }
        gateCard.addView(reqBox, matchWrap())

        val copyReqBtn = Button(this).apply {
            text = "Copy Request ID"
            textSize = 14f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            background = rounded(Color.rgb(242, 246, 253), 14, border)
            minHeight = dp(44)
            setOnClickListener {
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Request ID", requestId))
                Toast.makeText(this@MainActivity, "Copied: $requestId", Toast.LENGTH_SHORT).show()
            }
        }
        gateCard.addView(copyReqBtn, matchWrap().apply { topMargin = dp(10) })

        gateCard.addView(TextView(this).apply {
            text = "Enter Approval Code"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(18), 0, dp(6))
        })

        val codeInput = EditText(this).apply {
            hint = "e.g. KEY-AE4F2BEE"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        gateCard.addView(codeInput, matchWrap())

        val gateStatus = TextView(this).apply {
            text = ""
            textSize = 12f
            setTextColor(Color.rgb(190, 55, 65))
            setPadding(0, dp(8), 0, dp(4))
        }
        gateCard.addView(gateStatus, matchWrap())

        val activateBtn = actionButton("Activate & Unlock App", blue)
        activateBtn.setOnClickListener {
            val entered = codeInput.text.toString().trim().uppercase()
            val expected = computeApprovalKey(requestId)
            if (entered.isEmpty()) {
                gateStatus.text = "Please paste the Approval Code from Admin."
                return@setOnClickListener
            }
            if (entered == expected) {
                prefs.edit().putString("approved_key", entered).apply()
                Toast.makeText(this, "Approved! Welcome to Text to Voice.", Toast.LENGTH_SHORT).show()
                openMainApp()
            } else {
                gateStatus.text = "Invalid Approval Code for $requestId."
            }
        }
        gateCard.addView(activateBtn, matchWrap().apply { topMargin = dp(6) })

        root.addView(gateCard, matchWrap().apply { topMargin = dp(18) })
        root.addView(createCopyrightFooter(), matchWrap().apply { topMargin = dp(18) })

        scroll.addView(root)
        setContentView(scroll)
    }

    // ==================== 5-TAP COPYRIGHT -> ADMIN APPROVAL GENERATOR ====================
    private fun createCopyrightFooter(): TextView {
        return TextView(this).apply {
            text = "Copyright by : YEOM BROS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val now = System.currentTimeMillis()
                if (now - lastCopyrightTapTime > 2000L) {
                    copyrightTapCount = 0
                }
                lastCopyrightTapTime = now
                copyrightTapCount++
                if (copyrightTapCount >= 5) {
                    copyrightTapCount = 0
                    showAdminApprovalGeneratorDialog()
                }
            }
        }
    }

    private fun showAdminApprovalGeneratorDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(8))
        }

        container.addView(TextView(this).apply {
            text = "Enter the user's Request ID (e.g., REQ-1A2B3C) to generate their Approval Code:"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(14))
        })

        val reqInput = EditText(this).apply {
            hint = "REQ-1A2B3C"
            textSize = 17f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.WHITE, 14, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        container.addView(reqInput, matchWrap())

        val generatedKeyDisplay = TextView(this).apply {
            text = "KEY-XXXXXXXX"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(232, 241, 255), 14, border)
        }
        container.addView(generatedKeyDisplay, matchWrap().apply { topMargin = dp(12) })

        val copyKeyBtn = Button(this).apply {
            text = "Copy Approval Code"
            textSize = 15f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            background = rounded(Color.rgb(242, 245, 250), 14, border)
            minHeight = dp(48)
            setOnClickListener {
                val rawReq = reqInput.text.toString().trim().uppercase()
                if (rawReq.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Enter a Request ID first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val formattedReq = if (rawReq.startsWith("REQ-")) rawReq else "REQ-$rawReq"
                val key = computeApprovalKey(formattedReq)
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Approval Code", key))
                Toast.makeText(this@MainActivity, "Copied: $key", Toast.LENGTH_SHORT).show()
            }
        }
        container.addView(copyKeyBtn, matchWrap().apply { topMargin = dp(10) })

        reqInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val raw = s?.toString()?.trim()?.uppercase() ?: ""
                if (raw.isEmpty()) {
                    generatedKeyDisplay.text = "KEY-XXXXXXXX"
                } else {
                    val formattedReq = if (raw.startsWith("REQ-")) raw else "REQ-$raw"
                    generatedKeyDisplay.text = computeApprovalKey(formattedReq)
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        AlertDialog.Builder(this)
            .setTitle("Admin Approval Generator")
            .setView(container)
            .setPositiveButton("Close", null)
            .show()
    }

    // ==================== IMPROVED GENDER DETECTION & MALE/FEMALE VOICE ENGINE ====================
    private fun detectVoiceGender(voice: Voice): String {
        val raw = (voice.name + " " + voice.features.joinToString(" ")).lowercase(Locale.US)
        val femaleTokens = listOf(
            "female", "woman", "girl", "sfg", "tpf", "sfb", "sfc", "sfd",
            "iob", "iog", "gba", "gbc", "rjs", "khm-x-khm"
        )
        val maleTokens = listOf(
            "male", "man", "boy", "iom", "iol", "tpd", "sfa", "gbb", "gbd",
            "km-kh-x-khm-male", "khm-male"
        )
        if (Regex("\\bmale\\b").containsMatchIn(raw) && !raw.contains("female")) {
            return "Male"
        }
        if (maleTokens.any { raw.contains(it) }) {
            return "Male"
        }
        if (raw.contains("female") || femaleTokens.any { raw.contains(it) }) {
            return "Female"
        }
        return "Standard"
    }

    /**
     * Checks whether the currently selected voice is inherently a female-pitched base voice
     * (like Google's Khmer voice khm-x-khm-local or default female voices) so we can shift
     * pitch down into a true deep Male range (0.62 - 0.72) when Male Voice is chosen!
     */
    private fun isBaseVoiceFemale(): Boolean {
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            val v = voices[voiceSpinner.selectedItemPosition]
            val g = detectVoiceGender(v)
            if (g == "Male") return false
            if (g == "Female") return true
        }
        // On Android/Google TTS, Khmer and most default fallback voices are female by default
        return true
    }

    /**
     * Pitch slider has 15 steps (0..14):
     * pitch = 0.55f + progress * 0.05f  -> range 0.55x (Deep Male) up to 1.25x (Bright Female)
     * progress = 2 -> 0.65x (Deep Male on a female base voice)
     * progress = 9 -> 1.00x (Natural)
     * progress = 11 -> 1.10x (Bright Female)
     */
    private fun pitchFromProgress(progress: Int): Float {
        return 0.55f + progress.coerceIn(0, 14) * 0.05f
    }

    private fun buildExpressiveChunks(fullText: String): List<SpeechChunk> {
        val preset = emotions[selectedEmotionIndex.coerceIn(emotions.indices)]
        val rawParts = Regex("[^.!?។៕,\\n]+[.!?។៕,\\n]*")
            .findAll(fullText)
            .map { it.value.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val parts = if (rawParts.isEmpty()) listOf(fullText.trim()) else rawParts
        val result = mutableListOf<SpeechChunk>()

        for ((index, part) in parts.withIndex()) {
            val isQuestion = part.endsWith("?")
            val isExclamation = part.endsWith("!") || part.endsWith("៕")
            val isComma = part.endsWith(",")
            val isSentenceEnd = part.endsWith(".") || part.endsWith("។") || isQuestion || isExclamation

            var chunkRate = speed
            var chunkPitch = pitch

            // Subtle phrase-by-phrase melodic variation
            val wave = if (index % 2 == 0) preset.pitchSwing else -preset.pitchSwing * 0.6f
            chunkPitch += wave

            if (isQuestion) {
                chunkPitch += 0.09f
                chunkRate *= 0.96f
            } else if (isExclamation) {
                chunkPitch += 0.08f
                chunkRate *= 1.05f
            } else if (isSentenceEnd && selectedEmotionIndex == 2) {
                chunkPitch -= 0.05f
                chunkRate *= 0.94f
            }

            // If Male Voice is selected, clamp max pitch <= 0.82 so even questions stay convincingly male!
            if (selectedGenderFilter == 2 && isBaseVoiceFemale()) {
                chunkPitch = chunkPitch.coerceIn(0.52f, 0.80f)
            } else {
                chunkPitch = chunkPitch.coerceIn(0.52f, 1.55f)
            }

            val pauseMs = when {
                isComma -> preset.commaPauseMs
                isSentenceEnd -> preset.sentencePauseMs
                else -> 140L
            }

            result.add(
                SpeechChunk(
                    text = part,
                    rate = chunkRate.coerceIn(0.4f, 2.2f),
                    pitch = chunkPitch,
                    pauseAfterMs = pauseMs
                )
            )
        }
        return result
    }

    // ==================== MAIN TEXT-TO-VOICE UI ====================
    private fun saveUserWork() {
        if (!::textInput.isInitialized) return
        prefs.edit()
            .putInt("saved_lang", languageSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_gender", genderSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_emotion", emotionSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_speed", speedBar.progress)
            .putInt("saved_pitch", pitchBar.progress)
            .putString("saved_text", textInput.text.toString())
            .apply()
    }

    private fun restoreSavedUserWork() {
        val langIdx = prefs.getInt("saved_lang", 0).coerceIn(0, 1)
        languageSpinner.setSelection(langIdx)
        selectedLocale = if (langIdx == 0) Locale.US else Locale("km", "KH")

        val genderIdx = prefs.getInt("saved_gender", 0).coerceIn(0, 2)
        genderSpinner.setSelection(genderIdx)
        selectedGenderFilter = genderIdx

        val emotionIdx = prefs.getInt("saved_emotion", 0).coerceIn(emotions.indices)
        emotionSpinner.setSelection(emotionIdx)
        selectedEmotionIndex = emotionIdx
        emotionHintLabel.text = emotions[emotionIdx].description

        val prog = prefs.getInt("saved_speed", 5).coerceIn(0, 15)
        speedBar.progress = prog
        speed = 0.5f + prog * 0.1f
        updateSpeedLabel()

        val pProg = prefs.getInt("saved_pitch", 9).coerceIn(0, 14)
        pitchBar.progress = pProg
        pitch = pitchFromProgress(pProg)
        updatePitchLabel()

        val savedText = prefs.getString("saved_text", "") ?: ""
        textInput.setText(savedText)
        textInput.setSelection(textInput.text.length)
        countLabel.text = "${textInput.text.length} characters"
    }

    private fun updateSpeedLabel() {
        val label = when {
            speed < 0.9f -> "Slow"
            speed > 1.1f -> "Fast"
            else -> "Normal"
        }
        speedLabel.text = "$label · %.1f×".format(speed)
    }

    private fun updatePitchLabel() {
        val tone = when {
            pitch <= 0.78f -> "Deep Male Voice Tone"
            pitch <= 0.92f -> "Warm Male Tone"
            pitch >= 1.08f -> "Bright Female Tone"
            else -> "Natural Female / Standard Tone"
        }
        pitchLabel.text = "$tone · %.2f×".format(pitch)
    }

    private fun buildMainAppUi() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            setBackgroundColor(page)
        }
        val pageColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(blue, 24)
        }
        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topHeaderRow.addView(TextView(this).apply {
            text = "TEXT TO VOICE"
            textSize = 12f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))

        topHeaderRow.addView(TextView(this).apply {
            text = "Pro Verified"
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = rounded(darkBlue, 12)
        })
        header.addView(topHeaderRow, matchWrap())

        header.addView(TextView(this).apply {
            text = "Give your words a voice."
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(7), 0, dp(5))
        })
        header.addView(TextView(this).apply {
            text = "Write in English or Khmer, pick Female/Male voice & speaking feel, then play or save."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        pageColumn.addView(header, matchWrap())

        // 1. Language
        pageColumn.addView(sectionTitle("1. Choose your language"))
        val languageCard = card()
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "Khmer · ខ្មែរ")
        )
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedLocale = if (position == 0) Locale.US else Locale("km", "KH")
                saveUserWork()
                refreshVoices()
                applyGenderAndEmotionTone()
            }
        }
        languageCard.addView(languageSpinner, matchWrap())
        pageColumn.addView(languageCard, matchWrap())

        // 2. Female / Male Voice & Feel
        pageColumn.addView(sectionTitle("2. Voice gender & speaking feel"))
        val voiceCard = card()

        voiceCard.addView(TextView(this).apply {
            text = "Voice Gender (Male / Female)"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, 0, 0, dp(4))
        })

        genderSpinner = Spinner(this)
        genderSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("All Voices (Default)", "Female Voice (ស្រី)", "Male Voice (ប្រុស)")
        )
        genderSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedGenderFilter = position
                refreshVoices()
                applyGenderAndEmotionTone()
                saveUserWork()
            }
        }
        voiceCard.addView(genderSpinner, matchWrap())

        voiceCard.addView(TextView(this).apply {
            text = "Speaking Feel / Emotion (អារម្មណ៍នៃការនិយាយ)"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, dp(12), 0, dp(4))
        })

        emotionSpinner = Spinner(this)
        emotionSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            emotions.map { it.title }
        )
        emotionHintLabel = TextView(this).apply {
            text = emotions[0].description
            textSize = 12f
            setTextColor(blue)
            setPadding(0, dp(4), 0, dp(4))
        }
        emotionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedEmotionIndex = position
                emotionHintLabel.text = emotions[position].description
                applyGenderAndEmotionTone()
                saveUserWork()
            }
        }
        voiceCard.addView(emotionSpinner, matchWrap())
        voiceCard.addView(emotionHintLabel, matchWrap())

        voiceCard.addView(TextView(this).apply {
            text = "Installed Engine Voice"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, dp(10), 0, dp(4))
        })

        voiceSpinner = Spinner(this)
        voiceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyGenderAndEmotionTone()
            }
        }
        voiceCard.addView(voiceSpinner, matchWrap())
        pageColumn.addView(voiceCard, matchWrap())

        // 3. Text input
        pageColumn.addView(sectionTitle("3. Write your text"))
        val textCard = card()
        textInput = EditText(this).apply {
            hint = "Type or paste your English or Khmer text here… Use punctuation (. , ? ! ។) for natural emotional pauses."
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(false)
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            overScrollMode = View.OVER_SCROLL_ALWAYS
            movementMethod = ScrollingMovementMethod.getInstance()
            setOnTouchListener { v, event ->
                if (v.hasFocus()) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if ((event.action and MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP) {
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                }
                false
            }
        }
        textCard.addView(textInput, LinearLayout.LayoutParams(-1, dp(190)))

        val textTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(2))
        }
        val pasteButton = Button(this).apply {
            text = "Paste"
            textSize = 13f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.rgb(232, 241, 255), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this@MainActivity)
                    if (!pasted.isNullOrEmpty()) {
                        val start = textInput.selectionStart.coerceAtLeast(0)
                        val end = textInput.selectionEnd.coerceAtLeast(0)
                        textInput.text.replace(minOf(start, end), maxOf(start, end), pasted)
                        setStatus("Text pasted from clipboard.")
                    }
                } else setStatus("Clipboard is empty.")
            }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(190, 55, 65))
            background = rounded(Color.rgb(255, 239, 240), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                textInput.text.clear()
                setStatus("Text cleared.")
            }
        }
        textTools.addView(pasteButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textTools.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        textTools.addView(clearButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textCard.addView(textTools, matchWrap())

        countLabel = TextView(this).apply {
            text = "0 characters"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        textCard.addView(countLabel, matchWrap())
        textInput.addTextChangedListener(SimpleTextWatcher {
            countLabel.text = "${textInput.text.length} characters"
            saveUserWork()
        })
        pageColumn.addView(textCard, matchWrap())

        // 4. Fine-tune speed & tone
        pageColumn.addView(sectionTitle("4. Fine-tune speed & tone"))
        val speedCard = card()
        speedLabel = TextView(this).apply {
            text = "Normal · 1.0×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        speedCard.addView(speedLabel)
        speedBar = SeekBar(this).apply { max = 15; progress = 5 }
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = 0.5f + progress * 0.1f
                updateSpeedLabel()
                if (fromUser) saveUserWork()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(speedBar, matchWrap())

        pitchLabel = TextView(this).apply {
            text = "Natural Tone · 1.00×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(12), 0, 0)
        }
        speedCard.addView(pitchLabel)
        pitchBar = SeekBar(this).apply { max = 14; progress = 9 }
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                pitch = pitchFromProgress(progress)
                updatePitchLabel()
                if (fromUser) saveUserWork()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(pitchBar, matchWrap())
        speedCard.addView(TextView(this).apply {
            text = "Pitch range 0.55× (Deep Male) to 1.25× (Bright Female). Slide left for deeper Male voice."
            textSize = 12f
            setTextColor(muted)
        })
        pageColumn.addView(speedCard, matchWrap())

        // 5. Listen and save
        pageColumn.addView(sectionTitle("5. Listen and save"))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, 0)
        }
        val play = actionButton("▶   Play voice with feel", blue)
        play.setOnClickListener { speakText() }
        actions.addView(play, matchWrap())
        val stop = actionButton("■   Stop playback", Color.rgb(76, 91, 112))
        stop.setOnClickListener {
            speechQueue.clear()
            isSavingMultiChunk = false
            if (ready) tts.stop()
            setStatus("Playback stopped.")
        }
        val stopParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(stop, stopParams)
        val save = actionButton("↓   Save audio file", darkBlue)
        save.setOnClickListener { saveAudio() }
        val saveParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(save, saveParams)
        pageColumn.addView(actions)

        val statusCard = card().apply { setPadding(dp(14), dp(13), dp(14), dp(13)) }
        status = TextView(this).apply {
            text = "Starting speech engine…"
            textSize = 13f
            setTextColor(ink)
        }
        statusCard.addView(status)
        val statusParams = matchWrap().apply { topMargin = dp(16) }
        pageColumn.addView(statusCard, statusParams)

        pageColumn.addView(TextView(this).apply {
            text = "Khmer support: Google TTS only provides one female base voice for Khmer, so selecting Male Voice (ប្រុស) automatically lowers vocal pitch to 0.65×–0.70× to create a natural male voice."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(3), dp(14), dp(3), 0)
        }, matchWrap())

        pageColumn.addView(createCopyrightFooter(), matchWrap().apply { topMargin = dp(10) })

        scroll.addView(pageColumn)
        setContentView(scroll)
    }

    /**
     * Fixes the bug where selecting Emotion reset pitch back to 1.00x (female) even when Male was selected!
     * Now calculates base pitch from Gender + whether the underlying engine voice is female or native male,
     * and applies the Emotion's pitch offset ON TOP of the gender base pitch.
     */
    private fun applyGenderAndEmotionTone() {
        if (!::speedBar.isInitialized || !::pitchBar.isInitialized) return
        val preset = emotions[selectedEmotionIndex.coerceIn(emotions.indices)]

        val basePitchProgress = when (selectedGenderFilter) {
            2 -> { // Male Voice selected
                if (isBaseVoiceFemale()) {
                    // Underlying voice is female (e.g. Khmer khm-x-khm-local) -> drop to 0.65x (progress 2)
                    2
                } else {
                    // Native male voice (e.g. English en-us-x-iom) -> keep natural 0.95x (progress 8)
                    8
                }
            }
            1 -> { // Female Voice selected
                if (isBaseVoiceFemale()) 10 else 13
            }
            else -> 9 // All / Default (1.00x)
        }

        val targetSpeedProg = preset.speedProgress.coerceIn(0, 15)
        val targetPitchProg = if (selectedGenderFilter == 2 && isBaseVoiceFemale()) {
            // Keep Male voice firmly in the deep male range (progress 1..4 -> 0.60x..0.75x) across all emotions!
            (basePitchProgress + preset.pitchOffsetSteps).coerceIn(1, 4)
        } else {
            (basePitchProgress + preset.pitchOffsetSteps).coerceIn(0, 14)
        }

        speedBar.progress = targetSpeedProg
        pitchBar.progress = targetPitchProg
    }

    // ==================== UI HELPERS & EXPRESSIVE TTS ENGINE ====================
    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ink)
        setPadding(dp(2), dp(20), dp(2), dp(9))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = rounded(Color.WHITE, 18, border)
    }

    private fun actionButton(value: String, color: Int) = Button(this).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        minHeight = dp(52)
        elevation = dp(2).toFloat()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { if (::status.isInitialized) runOnUiThread { status.text = message } }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    if (!isSavingMultiChunk) {
                        val feelName = emotions[selectedEmotionIndex].title.substringBefore(" ·")
                        val gLabel = when (selectedGenderFilter) {
                            1 -> "Female"
                            2 -> "Male"
                            else -> "Standard"
                        }
                        setStatus("Speaking ($gLabel · $feelName)…")
                    }
                }
                override fun onDone(utteranceId: String?) {
                    if (isSavingMultiChunk) {
                        processNextSaveChunk()
                    } else if (speechQueue.isNotEmpty()) {
                        playNextSpeechChunk()
                    } else {
                        setStatus("Finished playing.")
                    }
                }
                override fun onError(utteranceId: String?) {
                    speechQueue.clear()
                    isSavingMultiChunk = false
                    setStatus("Speech failed. Please check that this language voice is installed.")
                }
            })
            setStatus("Speech engine ready. Enter text to begin.")
            refreshVoices()
            applyGenderAndEmotionTone()
        } else setStatus("Speech engine could not start. Check Android Text-to-speech settings.")
    }

    private fun refreshVoices() {
        if (!ready || !isDeviceActivated()) return
        val allVoices = tts.voices?.toList() ?: emptyList()
        val langVoices = allVoices.filter { it.locale.language == selectedLocale.language }
            .sortedWith(compareBy<Voice> { it.isNetworkConnectionRequired }.thenBy { it.name })

        val filtered = when (selectedGenderFilter) {
            1 -> langVoices.filter { detectVoiceGender(it) == "Female" }
            2 -> langVoices.filter { detectVoiceGender(it) == "Male" }
            else -> langVoices
        }

        voices = if (filtered.isNotEmpty()) filtered else langVoices

        val labels = if (voices.isEmpty()) {
            listOf("System default voice · pitch-adapted")
        } else {
            voices.map { v ->
                val detected = detectVoiceGender(v)
                val displayTag = if (selectedGenderFilter == 2 && detected != "Male") {
                    "Male Tone (Pitch-Adapted)"
                } else {
                    detected
                }
                val quality = if (v.quality >= Voice.QUALITY_HIGH) "High quality" else "Standard"
                "$displayTag · ${v.name} ($quality)"
            }
        }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val available = tts.isLanguageAvailable(selectedLocale)
        if (available < TextToSpeech.LANG_AVAILABLE) {
            setStatus(if (selectedLocale.language == "km")
                "No Khmer voice is currently available in your phone's speech engine."
            else "No English voice is currently available in your phone's speech engine.")
        } else {
            tts.language = selectedLocale
            if (voices.isNotEmpty()) tts.voice = voices.first()
            val genderDesc = when (selectedGenderFilter) {
                1 -> "Female"
                2 -> "Male"
                else -> "All"
            }
            setStatus("${labels.size} $genderDesc voice option(s) ready.")
        }
    }

    private fun prepareVoiceBase(): Boolean {
        if (!ready) { setStatus("Speech engine is still starting."); return false }
        val result = tts.setLanguage(selectedLocale)
        if (result < TextToSpeech.LANG_AVAILABLE) {
            setStatus("This language voice is not installed. Check Android Text-to-speech settings.")
            return false
        }
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            tts.voice = voices[voiceSpinner.selectedItemPosition]
        }
        return true
    }

    private fun speakText() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!prepareVoiceBase()) return
        tts.stop()
        isSavingMultiChunk = false
        pendingSaveUri = null

        speechQueue.clear()
        speechQueue.addAll(buildExpressiveChunks(text))
        playNextSpeechChunk(isFirst = true)
    }

    private fun playNextSpeechChunk(isFirst: Boolean = false) {
        val chunk = speechQueue.removeFirstOrNull() ?: return
        tts.setSpeechRate(chunk.rate)
        tts.setPitch(chunk.pitch)
        if (!isFirst && chunk.pauseAfterMs > 0L) {
            tts.playSilentUtterance(chunk.pauseAfterMs, TextToSpeech.QUEUE_ADD, "pause-${UUID.randomUUID()}")
        }
        val mode = if (isFirst) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts.speak(chunk.text, mode, null, "chunk-${UUID.randomUUID()}")
    }

    private fun saveAudio() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!prepareVoiceBase()) return
        val feelSlug = emotions[selectedEmotionIndex].title.substringBefore(" ").lowercase(Locale.US)
        val genderSlug = when (selectedGenderFilter) {
            1 -> "female"
            2 -> "male"
            else -> "voice"
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "TextToVoice-$genderSlug-$feelSlug-${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(intent, 44)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            val text = textInput.text.toString().trim()
            if (text.isEmpty() || !prepareVoiceBase()) return

            tts.stop()
            speechQueue.clear()
            tempChunkFiles.forEach { it.delete() }
            tempChunkFiles.clear()

            pendingSaveUri = data.data
            isSavingMultiChunk = true
            speechQueue.addAll(buildExpressiveChunks(text))
            setStatus("Generating expressive audio file…")
            processNextSaveChunk()
        }
    }

    private fun processNextSaveChunk() {
        val chunk = speechQueue.removeFirstOrNull()
        if (chunk != null) {
            val chunkFile = File(cacheDir, "chunk-${tempChunkFiles.size}-${System.currentTimeMillis()}.wav")
            tempChunkFiles.add(chunkFile)
            tts.setSpeechRate(chunk.rate)
            tts.setPitch(chunk.pitch)
            val res = tts.synthesizeToFile(chunk.text, Bundle(), chunkFile, "savechunk-${UUID.randomUUID()}")
            if (res != TextToSpeech.SUCCESS) {
                isSavingMultiChunk = false
                speechQueue.clear()
                setStatus("Could not synthesize audio chunk.")
            }
        } else {
            isSavingMultiChunk = false
            val uri = pendingSaveUri
            pendingSaveUri = null
            if (uri != null) {
                try {
                    mergeWavFilesToUri(tempChunkFiles, uri)
                    setStatus("Expressive audio saved successfully!")
                } catch (e: Exception) {
                    setStatus("Could not save audio: ${e.message ?: "unknown error"}")
                } finally {
                    tempChunkFiles.forEach { it.delete() }
                    tempChunkFiles.clear()
                }
            }
        }
    }

    private fun mergeWavFilesToUri(wavFiles: List<File>, destUri: Uri) {
        if (wavFiles.isEmpty()) throw IllegalStateException("No audio generated")
        if (wavFiles.size == 1) {
            contentResolver.openOutputStream(destUri)?.use { out ->
                wavFiles[0].inputStream().use { inp -> inp.copyTo(out) }
            }
            return
        }

        val pcmStream = ByteArrayOutputStream()
        var sampleRate = 22050
        var numChannels = 1
        var bitsPerSample = 16

        for ((idx, f) in wavFiles.withIndex()) {
            if (!f.exists() || f.length() <= 44) continue
            val bytes = f.readBytes()
            if (idx == 0 && bytes.size >= 44) {
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                numChannels = bb.getShort(22).toInt()
                sampleRate = bb.getInt(24)
                bitsPerSample = bb.getShort(34).toInt()
            }
            var offset = 12
            while (offset + 8 <= bytes.size) {
                val id = String(bytes, offset, 4, Charsets.US_ASCII)
                val size = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (id == "data") {
                    val dataStart = offset + 8
                    val dataLen = size.coerceAtMost(bytes.size - dataStart).coerceAtLeast(0)
                    pcmStream.write(bytes, dataStart, dataLen)
                    val pauseMs = emotions[selectedEmotionIndex].sentencePauseMs
                    val bytesPerSec = sampleRate * numChannels * (bitsPerSample / 8)
                    val silenceBytes = ((bytesPerSec * pauseMs) / 1000L).toInt() and 0x7FFFFFFE
                    if (silenceBytes > 0) {
                        pcmStream.write(ByteArray(silenceBytes))
                    }
                    break
                }
                offset += 8 + size
            }
        }

        val totalPcm = pcmStream.toByteArray()
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)
        val blockAlign = (numChannels * (bitsPerSample / 8)).toShort()
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(36 + totalPcm.size)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1)
            putShort(numChannels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign)
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(totalPcm.size)
        }.array()

        contentResolver.openOutputStream(destUri)?.use { out ->
            out.write(header)
            out.write(totalPcm)
        } ?: throw IllegalStateException("Could not open destination file")
    }

    override fun onPause() {
        saveUserWork()
        super.onPause()
    }

    override fun onDestroy() {
        saveUserWork()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
