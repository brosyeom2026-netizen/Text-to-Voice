package com.texttovoice.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private lateinit var languageSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var countLabel: TextView
    private lateinit var activeUserBadge: TextView

    private var ready = false
    private var selectedLocale: Locale = Locale.US
    private var voices: List<android.speech.tts.Voice> = emptyList()
    private var pendingOutput: File? = null
    private var pendingSaveUri: Uri? = null
    private var speed = 1.0f

    // Secret 5-tap Admin Verification Manager trigger
    private var copyrightTapCount = 0
    private var lastCopyrightTapTime = 0L

    // Brute-force protection
    private var failedAttempts = 0
    private var lockoutUntilMs = 0L

    // Admin secret salt for offline activation key generation/verification
    private val adminMasterSecret = "YEOM_BROS_2026_SECURE_KEY"

    data class AuthorizedUser(
        val id: String,
        var name: String,
        var accessCode: String,
        var boundDeviceId: String = "",
        var isApproved: Boolean = false,
        var isAdmin: Boolean = false,
        var languageIndex: Int = 0,
        var speedProgress: Int = 5,
        var savedText: String = ""
    )

    private val users = mutableListOf<AuthorizedUser>()
    private var currentUserId: String = ""
    private var isAuthenticated = false

    private val blue = Color.rgb(31, 105, 220)
    private val darkBlue = Color.rgb(20, 68, 150)
    private val ink = Color.rgb(27, 39, 58)
    private val muted = Color.rgb(105, 119, 140)
    private val page = Color.rgb(244, 247, 252)
    private val border = Color.rgb(225, 232, 242)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("yeom_bros_ttv_strict_v2", Context.MODE_PRIVATE)
        loadUsers()

        window.statusBarColor = page
        window.navigationBarColor = Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        // If first time ever launching, force Admin setup or show strict login screen
        if (!prefs.getBoolean("admin_configured", false)) {
            showFirstTimeAdminSetup()
        } else {
            showLoginScreen()
        }
    }

    private fun getDeviceFingerprint(): String {
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEVICE"
        val digest = MessageDigest.getInstance("SHA-256").digest(androidId.toByteArray())
        val hex = digest.take(4).joinToString("") { "%02X".format(it) }
        return "${hex.substring(0, 4)}-${hex.substring(4, 8)}"
    }

    /**
     * Generates a deterministic 8-character Approval Activation Code tied to a specific Device ID + Username.
     * Even if another user is on a separate phone without shared local storage, Admin can generate this code
     * on Admin's phone and send it to the user to unlock their device!
     */
    private fun generateApprovalKey(deviceId: String, username: String): String {
        val normalized = "${deviceId.trim().uppercase()}|${username.trim().lowercase()}|$adminMasterSecret"
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
        val hex = digest.take(4).joinToString("") { "%02X".format(it) }
        return "${hex.substring(0, 4)}-${hex.substring(4, 8)}"
    }

    private fun loadUsers() {
        users.clear()
        val raw = prefs.getString("users_json", null)
        if (!raw.isNullOrEmpty()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    users.add(
                        AuthorizedUser(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            name = obj.optString("name", "User ${i + 1}"),
                            accessCode = obj.optString("accessCode", ""),
                            boundDeviceId = obj.optString("boundDeviceId", ""),
                            isApproved = obj.optBoolean("isApproved", false),
                            isAdmin = obj.optBoolean("isAdmin", false),
                            languageIndex = obj.optInt("languageIndex", 0),
                            speedProgress = obj.optInt("speedProgress", 5),
                            savedText = obj.optString("savedText", "")
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
        saveUsers()
    }

    private fun saveUsers() {
        val arr = JSONArray()
        for (u in users) {
            val obj = JSONObject().apply {
                put("id", u.id)
                put("name", u.name)
                put("accessCode", u.accessCode)
                put("boundDeviceId", u.boundDeviceId)
                put("isApproved", u.isApproved)
                put("isAdmin", u.isAdmin)
                put("languageIndex", u.languageIndex)
                put("speedProgress", u.speedProgress)
                put("savedText", u.savedText)
            }
            arr.put(obj)
        }
        prefs.edit()
            .putString("users_json", arr.toString())
            .apply()
    }

    private fun currentUser(): AuthorizedUser {
        return users.firstOrNull { it.id == currentUserId } ?: users.first()
    }

    // ==================== FIRST-TIME ADMIN SETUP ====================
    private fun showFirstTimeAdminSetup() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(page)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(32), dp(22), dp(28))
        }

        val headerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = rounded(darkBlue, 24)
        }
        headerCard.addView(TextView(this).apply {
            text = "YEOM BROS · SECURITY SETUP"
            textSize = 11f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        })
        headerCard.addView(TextView(this).apply {
            text = "Create Private Admin PIN"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        })
        headerCard.addView(TextView(this).apply {
            text = "Set your secret Admin username and PIN so no unauthorized user can access or approve accounts."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        root.addView(headerCard, matchWrap())

        val setupCard = card().apply { setPadding(dp(18), dp(20), dp(18), dp(20)) }
        val adminNameInput = EditText(this).apply {
            setText("YEOM BROS")
            hint = "Admin Username"
            textSize = 16f
            setTextColor(ink)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
        }
        val adminPinInput = EditText(this).apply {
            hint = "Create Secret Admin PIN (min 4 chars)"
            textSize = 16f
            setTextColor(ink)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val setupStatus = TextView(this).apply {
            text = "This device will be bound as the Master Admin device (${getDeviceFingerprint()})."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(10), 0, dp(8))
        }
        val saveAdminBtn = actionButton("Save Admin & Continue", blue)
        saveAdminBtn.setOnClickListener {
            val name = adminNameInput.text.toString().trim()
            val pin = adminPinInput.text.toString().trim()
            if (name.isEmpty() || pin.length < 4) {
                setupStatus.setTextColor(Color.rgb(190, 55, 65))
                setupStatus.text = "Please enter an Admin name and a PIN with at least 4 characters."
                return@setOnClickListener
            }
            users.clear()
            users.add(
                AuthorizedUser(
                    id = "admin-master",
                    name = name,
                    accessCode = pin,
                    boundDeviceId = getDeviceFingerprint(),
                    isApproved = true,
                    isAdmin = true
                )
            )
            saveUsers()
            prefs.edit().putBoolean("admin_configured", true).apply()
            Toast.makeText(this, "Admin security configured!", Toast.LENGTH_SHORT).show()
            showLoginScreen()
        }

        setupCard.addView(TextView(this).apply {
            text = "Admin Username"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })
        setupCard.addView(adminNameInput, matchWrap())
        setupCard.addView(TextView(this).apply {
            text = "Secret Admin PIN"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(14), 0, dp(6))
        })
        setupCard.addView(adminPinInput, matchWrap())
        setupCard.addView(setupStatus, matchWrap())
        setupCard.addView(saveAdminBtn, matchWrap())

        root.addView(setupCard, matchWrap().apply { topMargin = dp(18) })
        scroll.addView(root)
        setContentView(scroll)
    }

    // ==================== STRICT LOGIN & ADMIN APPROVAL GATE ====================
    private fun showLoginScreen() {
        isAuthenticated = false
        val deviceId = getDeviceFingerprint()

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(page)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }

        // Top Brand Card
        val brandCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = rounded(blue, 24)
        }
        brandCard.addView(TextView(this).apply {
            text = "TEXT TO VOICE · PROTECTED ACCESS"
            textSize = 11f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        })
        brandCard.addView(TextView(this).apply {
            text = "Admin Approval Required"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        })
        brandCard.addView(TextView(this).apply {
            text = "Only users verified and approved by Admin can log in on this device."
            textSize = 13f
            setTextColor(Color.rgb(235, 242, 255))
        })
        root.addView(brandCard, matchWrap())

        // Strict Login Card (No public dropdown, no default PIN hint)
        val loginCard = card().apply {
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }

        loginCard.addView(TextView(this).apply {
            text = "Username"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })
        val usernameInput = EditText(this).apply {
            hint = "Enter your approved username"
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
        }
        loginCard.addView(usernameInput, matchWrap())

        loginCard.addView(TextView(this).apply {
            text = "Secret PIN"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(14), 0, dp(6))
        })
        val pinInput = EditText(this).apply {
            hint = "Enter your secret PIN"
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        loginCard.addView(pinInput, matchWrap())

        val loginStatus = TextView(this).apply {
            text = "Device ID: $deviceId (Tap to copy)"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(10), 0, dp(4))
            isClickable = true
            setOnClickListener {
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Device ID", deviceId))
                Toast.makeText(this@MainActivity, "Copied Device ID: $deviceId", Toast.LENGTH_SHORT).show()
            }
        }
        loginCard.addView(loginStatus, matchWrap())

        val loginBtn = actionButton("Verify & Login", blue)
        loginBtn.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now < lockoutUntilMs) {
                val secs = ((lockoutUntilMs - now) / 1000L) + 1
                loginStatus.setTextColor(Color.rgb(190, 55, 65))
                loginStatus.text = "Too many failed attempts. Locked for ${secs}s."
                return@setOnClickListener
            }

            val enteredName = usernameInput.text.toString().trim()
            val enteredPin = pinInput.text.toString().trim()

            if (enteredName.isEmpty() || enteredPin.isEmpty()) {
                loginStatus.setTextColor(Color.rgb(190, 55, 65))
                loginStatus.text = "Please enter both Username and Secret PIN."
                return@setOnClickListener
            }

            val matchedUser = users.firstOrNull {
                it.name.equals(enteredName, ignoreCase = true) && it.accessCode == enteredPin
            }

            if (matchedUser == null) {
                failedAttempts++
                if (failedAttempts >= 3) {
                    lockoutUntilMs = System.currentTimeMillis() + 60_000L
                    failedAttempts = 0
                    loginStatus.setTextColor(Color.rgb(190, 55, 65))
                    loginStatus.text = "3 failed attempts. Login locked for 60 seconds."
                } else {
                    loginStatus.setTextColor(Color.rgb(190, 55, 65))
                    loginStatus.text = "Invalid username or PIN (${3 - failedAttempts} attempt(s) left)."
                }
                return@setOnClickListener
            }

            // Check Admin approval status
            if (!matchedUser.isApproved) {
                loginStatus.setTextColor(Color.rgb(190, 55, 65))
                loginStatus.text = "Pending Admin Approval: '${matchedUser.name}' is not approved yet."
                return@setOnClickListener
            }

            // Check Device ID binding (hardware lock)
            if (matchedUser.boundDeviceId.isNotEmpty() && matchedUser.boundDeviceId != deviceId) {
                loginStatus.setTextColor(Color.rgb(190, 55, 65))
                loginStatus.text = "Device Mismatch: This account is locked to another phone (${matchedUser.boundDeviceId})."
                return@setOnClickListener
            }

            // Bind device on first approved login if unbound
            if (matchedUser.boundDeviceId.isEmpty()) {
                matchedUser.boundDeviceId = deviceId
                saveUsers()
            }

            failedAttempts = 0
            currentUserId = matchedUser.id
            isAuthenticated = true
            buildMainAppUi()
            applyCurrentUserToUi()
            if (!::tts.isInitialized) {
                tts = TextToSpeech(this, this)
            } else if (ready) {
                refreshVoices()
            }
        }
        loginCard.addView(loginBtn, matchWrap().apply { topMargin = dp(10) })

        // New User Request Button (Creates Pending account requiring Admin Approval)
        val requestBtn = Button(this).apply {
            text = "Request Admin Approval (New User)"
            textSize = 13f
            isAllCaps = false
            setTextColor(darkBlue)
            background = rounded(Color.rgb(232, 241, 255), 14)
            minHeight = dp(44)
            setOnClickListener { showRequestApprovalDialog() }
        }
        loginCard.addView(requestBtn, matchWrap().apply { topMargin = dp(10) })

        // Enter Admin Approval Code Button (For activating a user on a separate device)
        val activateKeyBtn = Button(this).apply {
            text = "Have an Admin Approval Code? Activate Here"
            textSize = 12f
            isAllCaps = false
            setTextColor(muted)
            background = rounded(Color.rgb(244, 247, 252), 12, border)
            minHeight = dp(40)
            setOnClickListener { showActivateWithAdminKeyDialog() }
        }
        loginCard.addView(activateKeyBtn, matchWrap().apply { topMargin = dp(8) })

        root.addView(loginCard, matchWrap().apply { topMargin = dp(18) })
        root.addView(createCopyrightFooter(onLoginScreen = true), matchWrap().apply { topMargin = dp(16) })

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showRequestApprovalDialog() {
        val deviceId = getDeviceFingerprint()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val info = TextView(this).apply {
            text = "Your Device ID: $deviceId\nYour account will stay LOCKED until Admin approves it."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        }
        val nameBox = EditText(this).apply {
            hint = "Enter Your Username"
            setSingleLine(true)
        }
        val pinBox = EditText(this).apply {
            hint = "Create Your Secret PIN (min 4 chars)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        container.addView(info)
        container.addView(nameBox)
        container.addView(pinBox, matchWrap().apply { topMargin = dp(10) })

        AlertDialog.Builder(this)
            .setTitle("Request Admin Approval")
            .setView(container)
            .setPositiveButton("Submit Request") { _, _ ->
                val name = nameBox.text.toString().trim()
                val pin = pinBox.text.toString().trim()
                if (name.isEmpty() || pin.length < 4) {
                    Toast.makeText(this, "Enter a username and PIN (4+ chars)", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (users.any { it.name.equals(name, ignoreCase = true) }) {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                users.add(
                    AuthorizedUser(
                        id = UUID.randomUUID().toString(),
                        name = name,
                        accessCode = pin,
                        boundDeviceId = deviceId,
                        isApproved = false, // Must be approved by Admin!
                        isAdmin = false
                    )
                )
                saveUsers()
                AlertDialog.Builder(this)
                    .setTitle("Approval Pending")
                    .setMessage(
                        "Request saved for '$name'.\n\n" +
                        "Send your Device ID ($deviceId) and Username ($name) to Admin for approval."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showActivateWithAdminKeyDialog() {
        val deviceId = getDeviceFingerprint()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val info = TextView(this).apply {
            text = "Share your Device ID ($deviceId) with Admin to receive your 8-character Approval Code."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        }
        val nameBox = EditText(this).apply {
            hint = "Your Username"
            setSingleLine(true)
        }
        val pinBox = EditText(this).apply {
            hint = "Your Secret PIN"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val keyBox = EditText(this).apply {
            hint = "Admin Approval Code (e.g. A1B2-C3D4)"
            setSingleLine(true)
        }
        container.addView(info)
        container.addView(nameBox)
        container.addView(pinBox, matchWrap().apply { topMargin = dp(8) })
        container.addView(keyBox, matchWrap().apply { topMargin = dp(8) })

        AlertDialog.Builder(this)
            .setTitle("Activate with Admin Code")
            .setView(container)
            .setPositiveButton("Verify Code") { _, _ ->
                val name = nameBox.text.toString().trim()
                val pin = pinBox.text.toString().trim()
                val enteredKey = keyBox.text.toString().trim().uppercase()
                val expectedKey = generateApprovalKey(deviceId, name)

                if (name.isEmpty() || pin.length < 4) {
                    Toast.makeText(this, "Enter valid username and PIN (4+ chars)", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (enteredKey == expectedKey) {
                    val existing = users.firstOrNull { it.name.equals(name, ignoreCase = true) }
                    if (existing != null) {
                        existing.accessCode = pin
                        existing.boundDeviceId = deviceId
                        existing.isApproved = true
                    } else {
                        users.add(
                            AuthorizedUser(
                                id = UUID.randomUUID().toString(),
                                name = name,
                                accessCode = pin,
                                boundDeviceId = deviceId,
                                isApproved = true,
                                isAdmin = false
                            )
                        )
                    }
                    saveUsers()
                    Toast.makeText(this, "Device Approved! You can now log in.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Invalid Admin Approval Code for this device.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ==================== MAIN APP UI (AFTER APPROVAL & LOGIN) ====================
    private fun persistCurrentUserState() {
        if (!isAuthenticated || !::textInput.isInitialized) return
        val u = currentUser()
        u.languageIndex = languageSpinner.selectedItemPosition.coerceAtLeast(0)
        u.speedProgress = speedBar.progress
        u.savedText = textInput.text.toString()
        saveUsers()
    }

    private fun applyCurrentUserToUi() {
        val u = currentUser()
        activeUserBadge.text = "✓ ${u.name} · Logout"
        val langIdx = u.languageIndex.coerceIn(0, 1)
        languageSpinner.setSelection(langIdx)
        selectedLocale = if (langIdx == 0) Locale.US else Locale("km", "KH")

        val prog = u.speedProgress.coerceIn(0, 15)
        speedBar.progress = prog
        speed = 0.5f + prog * 0.1f
        val label = when {
            speed < 0.9f -> "Slow"
            speed > 1.1f -> "Fast"
            else -> "Normal"
        }
        speedLabel.text = "$label · %.1f×".format(speed)

        textInput.setText(u.savedText)
        textInput.setSelection(textInput.text.length)
        countLabel.text = "${textInput.text.length} characters"
        if (ready) refreshVoices()
    }

    private fun buildMainAppUi() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            setBackgroundColor(page)
        }
        val pageColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(blue, 24)
        }
        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topHeaderRow.addView(TextView(this).apply {
            text = "TEXT TO VOICE"
            textSize = 12f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))

        activeUserBadge = TextView(this).apply {
            text = "✓ Verified · Logout"
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = rounded(darkBlue, 12)
            isClickable = true
            setOnClickListener {
                persistCurrentUserState()
                if (ready) tts.stop()
                showLoginScreen()
            }
        }
        topHeaderRow.addView(activeUserBadge)
        header.addView(topHeaderRow, matchWrap())

        header.addView(TextView(this).apply {
            text = "Give your words a voice."
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(7), 0, dp(5))
        })
        header.addView(TextView(this).apply {
            text = "Write in English or Khmer, choose an installed voice, then listen or save your audio."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        pageColumn.addView(header, matchWrap())

        pageColumn.addView(sectionTitle("1. Choose your language"))
        val languageCard = card()
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "Khmer · ខ្មែរ")
        )
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedLocale = if (position == 0) Locale.US else Locale("km", "KH")
                persistCurrentUserState()
                refreshVoices()
            }
        }
        languageCard.addView(languageSpinner, matchWrap())
        pageColumn.addView(languageCard, matchWrap())

        pageColumn.addView(sectionTitle("2. Pick a voice"))
        val voiceCard = card()
        voiceSpinner = Spinner(this)
        voiceCard.addView(voiceSpinner, matchWrap())
        voiceCard.addView(TextView(this).apply {
            text = "Voice choices come from the speech engine installed on your phone. Voice names and male/female options vary by engine."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(8), 0, 0)
        })
        pageColumn.addView(voiceCard, matchWrap())

        pageColumn.addView(sectionTitle("3. Write your text"))
        val textCard = card()
        textInput = EditText(this).apply {
            hint = "Type or paste your English or Khmer text here…"
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(false)
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            overScrollMode = View.OVER_SCROLL_ALWAYS
            movementMethod = ScrollingMovementMethod.getInstance()
            setOnTouchListener { v, event ->
                if (v.hasFocus()) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if ((event.action and MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP) {
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                }
                false
            }
        }
        textCard.addView(textInput, LinearLayout.LayoutParams(-1, dp(190)))

        val textTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(2))
        }
        val pasteButton = Button(this).apply {
            text = "Paste"
            textSize = 13f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.rgb(232, 241, 255), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this@MainActivity)
                    if (!pasted.isNullOrEmpty()) {
                        val start = textInput.selectionStart.coerceAtLeast(0)
                        val end = textInput.selectionEnd.coerceAtLeast(0)
                        textInput.text.replace(minOf(start, end), maxOf(start, end), pasted)
                        setStatus("Text pasted from clipboard.")
                    }
                } else setStatus("Clipboard is empty.")
            }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(190, 55, 65))
            background = rounded(Color.rgb(255, 239, 240), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                textInput.text.clear()
                setStatus("Text cleared.")
            }
        }
        textTools.addView(pasteButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textTools.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        textTools.addView(clearButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textCard.addView(textTools, matchWrap())

        countLabel = TextView(this).apply {
            text = "0 characters"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        textCard.addView(countLabel, matchWrap())
        textInput.addTextChangedListener(SimpleTextWatcher {
            countLabel.text = "${textInput.text.length} characters"
            persistCurrentUserState()
        })
        pageColumn.addView(textCard, matchWrap())

        pageColumn.addView(sectionTitle("4. Speaking speed"))
        val speedCard = card()
        speedLabel = TextView(this).apply {
            text = "Normal · 1.0×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        speedCard.addView(speedLabel)
        speedBar = SeekBar(this).apply { max = 15; progress = 5 }
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = 0.5f + progress * 0.1f
                val label = when {
                    speed < 0.9f -> "Slow"
                    speed > 1.1f -> "Fast"
                    else -> "Normal"
                }
                speedLabel.text = "$label · %.1f×".format(speed)
                if (fromUser) persistCurrentUserState()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(speedBar, matchWrap())
        speedCard.addView(TextView(this).apply {
            text = "Move the slider left for slower speech or right for faster speech."
            textSize = 12f
            setTextColor(muted)
        })
        pageColumn.addView(speedCard, matchWrap())

        pageColumn.addView(sectionTitle("5. Listen and save"))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, 0)
        }
        val play = actionButton("▶   Play voice", blue)
        play.setOnClickListener { speakText() }
        actions.addView(play, matchWrap())
        val stop = actionButton("■   Stop playback", Color.rgb(76, 91, 112))
        stop.setOnClickListener {
            if (ready) tts.stop()
            setStatus("Playback stopped.")
        }
        val stopParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(stop, stopParams)
        val save = actionButton("↓   Save audio file", darkBlue)
        save.setOnClickListener { saveAudio() }
        val saveParams = matchWrap().apply { topMargin = dp(9) }
        actions.addView(save, saveParams)
        pageColumn.addView(actions)

        val statusCard = card().apply { setPadding(dp(14), dp(13), dp(14), dp(13)) }
        status = TextView(this).apply {
            text = "Starting speech engine…"
            textSize = 13f
            setTextColor(ink)
        }
        statusCard.addView(status)
        val statusParams = matchWrap().apply { topMargin = dp(16) }
        pageColumn.addView(statusCard, statusParams)

        pageColumn.addView(TextView(this).apply {
            text = "Khmer support: your phone must have a Khmer text-to-speech voice installed. If Khmer is unavailable, check Settings → Accessibility or Text-to-speech output and install a compatible voice if offered."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(3), dp(14), dp(3), 0)
        }, matchWrap())

        pageColumn.addView(createCopyrightFooter(onLoginScreen = false), matchWrap().apply { topMargin = dp(10) })

        scroll.addView(pageColumn)
        setContentView(scroll)
    }

    // ==================== 5-TAP COPYRIGHT ADMIN APPROVAL MANAGER ====================
    private fun createCopyrightFooter(onLoginScreen: Boolean): TextView {
        return TextView(this).apply {
            text = "Copyright by : YEOM BROS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val now = System.currentTimeMillis()
                if (now - lastCopyrightTapTime > 2000L) {
                    copyrightTapCount = 0
                }
                lastCopyrightTapTime = now
                copyrightTapCount++
                if (copyrightTapCount >= 5) {
                    copyrightTapCount = 0
                    promptAdminVerification(onLoginScreen)
                }
            }
        }
    }

    private fun promptAdminVerification(onLoginScreen: Boolean) {
        val adminUser = users.firstOrNull { it.isAdmin } ?: return
        val pinBox = EditText(this).apply {
            hint = "Enter Private Admin PIN"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("YEOM BROS · Admin Control")
            .setMessage("Enter your secret Admin PIN to approve or manage users:")
            .setView(pinBox)
            .setPositiveButton("Unlock") { _, _ ->
                if (pinBox.text.toString().trim() == adminUser.accessCode) {
                    showAdminApprovalManager(onLoginScreen)
                } else {
                    Toast.makeText(this, "Access Denied: Wrong Admin PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAdminApprovalManager(onLoginScreen: Boolean) {
        persistCurrentUserState()
        val items = users.map { u ->
            val badge = if (u.isApproved) "✅ APPROVED" else "🔒 WAITING FOR ADMIN APPROVAL"
            val role = if (u.isAdmin) " [MASTER ADMIN]" else ""
            val dev = if (u.boundDeviceId.isNotEmpty()) u.boundDeviceId else "Unbound"
            "${u.name}$role\n$badge  ·  Device: $dev"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Admin User Approval (${users.size})")
            .setItems(items) { _, which ->
                showManageSingleUserDialog(users[which], onLoginScreen)
            }
            .setPositiveButton("+ Add / Generate Code") { _, _ ->
                showAddOrGenerateCodeChoice(onLoginScreen)
            }
            .setNegativeButton("Done") { _, _ ->
                if (onLoginScreen) showLoginScreen()
            }
            .show()
    }

    private fun showAddOrGenerateCodeChoice(onLoginScreen: Boolean) {
        val choices = arrayOf(
            "1. Create Approved User (This Phone)",
            "2. Generate Remote Approval Code (Another Phone)"
        )
        AlertDialog.Builder(this)
            .setTitle("Approve New User")
            .setItems(choices) { _, which ->
                if (which == 0) {
                    showAddUserDialog(onLoginScreen)
                } else {
                    showGenerateRemoteCodeDialog(onLoginScreen)
                }
            }
            .setNegativeButton("Back") { _, _ -> showAdminApprovalManager(onLoginScreen) }
            .show()
    }

    private fun showGenerateRemoteCodeDialog(onLoginScreen: Boolean) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val devBox = EditText(this).apply {
            hint = "User's Device ID (e.g. A1B2-C3D4)"
            setSingleLine(true)
        }
        val userBox = EditText(this).apply {
            hint = "User's Username"
            setSingleLine(true)
        }
        container.addView(devBox)
        container.addView(userBox, matchWrap().apply { topMargin = dp(10) })

        AlertDialog.Builder(this)
            .setTitle("Generate Approval Code")
            .setMessage("Enter the Device ID and Username from the other user's phone:")
            .setView(container)
            .setPositiveButton("Generate Code") { _, _ ->
                val dev = devBox.text.toString().trim().uppercase()
                val uname = userBox.text.toString().trim()
                if (dev.isEmpty() || uname.isEmpty()) {
                    Toast.makeText(this, "Enter both Device ID and Username", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val code = generateApprovalKey(dev, uname)
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Approval Code", code))

                AlertDialog.Builder(this)
                    .setTitle("Approval Code Ready")
                    .setMessage("Username: $uname\nDevice ID: $dev\n\nApproval Code: $code\n\n(Copied to clipboard — send this code to the user)")
                    .setPositiveButton("OK") { _, _ -> showAdminApprovalManager(onLoginScreen) }
                    .show()
            }
            .setNegativeButton("Cancel") { _, _ -> showAdminApprovalManager(onLoginScreen) }
            .show()
    }

    private fun showManageSingleUserDialog(user: AuthorizedUser, onLoginScreen: Boolean) {
        val toggleLabel = if (user.isApproved) "Revoke / Block User Access" else "✅ Approve User Access"
        val options = mutableListOf(
            toggleLabel,
            "Change Secret PIN",
            "Reset Device Binding (${if (user.boundDeviceId.isEmpty()) "Unbound" else user.boundDeviceId})",
            "Rename User"
        )
        if (!user.isAdmin && users.size > 1) {
            options.add("Delete User")
        }

        AlertDialog.Builder(this)
            .setTitle("Admin Manage: ${user.name}")
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> {
                        if (user.isAdmin) {
                            Toast.makeText(this, "Master Admin cannot be blocked.", Toast.LENGTH_SHORT).show()
                        } else {
                            user.isApproved = !user.isApproved
                            saveUsers()
                            val stateText = if (user.isApproved) "APPROVED" else "BLOCKED"
                            Toast.makeText(this, "${user.name} is now $stateText", Toast.LENGTH_SHORT).show()
                        }
                        showAdminApprovalManager(onLoginScreen)
                    }
                    1 -> showChangePinDialog(user, onLoginScreen)
                    2 -> {
                        user.boundDeviceId = ""
                        saveUsers()
                        Toast.makeText(this, "Device lock cleared for ${user.name}", Toast.LENGTH_SHORT).show()
                        showAdminApprovalManager(onLoginScreen)
                    }
                    3 -> showRenameUserDialog(user, onLoginScreen)
                    4 -> {
                        users.removeAll { it.id == user.id }
                        saveUsers()
                        Toast.makeText(this, "Deleted ${user.name}", Toast.LENGTH_SHORT).show()
                        showAdminApprovalManager(onLoginScreen)
                    }
                }
            }
            .setNegativeButton("Back") { _, _ -> showAdminApprovalManager(onLoginScreen) }
            .show()
    }

    private fun showAddUserDialog(onLoginScreen: Boolean) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val nameBox = EditText(this).apply {
            hint = "Approved Username"
            setSingleLine(true)
        }
        val pinBox = EditText(this).apply {
            hint = "Assign Secret PIN (4+ chars)"
            setSingleLine(true)
        }
        container.addView(nameBox)
        container.addView(pinBox, matchWrap().apply { topMargin = dp(10) })

        AlertDialog.Builder(this)
            .setTitle("Create Approved User")
            .setView(container)
            .setPositiveButton("Approve & Save") { _, _ ->
                val name = nameBox.text.toString().trim()
                val pin = pinBox.text.toString().trim()
                if (name.isNotEmpty() && pin.length >= 4) {
                    users.add(
                        AuthorizedUser(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            accessCode = pin,
                            boundDeviceId = "",
                            isApproved = true,
                            isAdmin = false
                        )
                    )
                    saveUsers()
                    Toast.makeText(this, "Approved user created: $name", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Username and 4+ char PIN required", Toast.LENGTH_SHORT).show()
                }
                showAdminApprovalManager(onLoginScreen)
            }
            .setNegativeButton("Cancel") { _, _ -> showAdminApprovalManager(onLoginScreen) }
            .show()
    }

    private fun showChangePinDialog(user: AuthorizedUser, onLoginScreen: Boolean) {
        val input = EditText(this).apply {
            hint = "New Secret PIN (4+ chars)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Change PIN for ${user.name}")
            .setView(input)
            .setPositiveButton("Save PIN") { _, _ ->
                val newPin = input.text.toString().trim()
                if (newPin.length >= 4) {
                    user.accessCode = newPin
                    saveUsers()
                    Toast.makeText(this, "Updated PIN for ${user.name}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN must be at least 4 characters", Toast.LENGTH_SHORT).show()
                }
                showAdminApprovalManager(onLoginScreen)
            }
            .setNegativeButton("Cancel") { _, _ -> showManageSingleUserDialog(user, onLoginScreen) }
            .show()
    }

    private fun showRenameUserDialog(user: AuthorizedUser, onLoginScreen: Boolean) {
        val input = EditText(this).apply {
            setText(user.name)
            setSelection(user.name.length)
            setSingleLine(true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Rename User")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    user.name = newName
                    saveUsers()
                    if (isAuthenticated && user.id == currentUserId) {
                        applyCurrentUserToUi()
                    }
                }
                showAdminApprovalManager(onLoginScreen)
            }
            .setNegativeButton("Cancel") { _, _ -> showManageSingleUserDialog(user, onLoginScreen) }
            .show()
    }

    // ==================== UI HELPERS & TTS ENGINE ====================
    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ink)
        setPadding(dp(2), dp(20), dp(2), dp(9))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = rounded(Color.WHITE, 18, border)
    }

    private fun actionButton(value: String, color: Int) = Button(this).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        minHeight = dp(52)
        elevation = dp(2).toFloat()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { if (::status.isInitialized) runOnUiThread { status.text = message } }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { setStatus("Creating your audio…") }
                override fun onDone(utteranceId: String?) {
                    val file = pendingOutput
                    val uri = pendingSaveUri
                    if (file != null && uri != null) {
                        try {
                            contentResolver.openOutputStream(uri)?.use { output ->
                                file.inputStream().use { input -> input.copyTo(output) }
                            } ?: throw IllegalStateException("Could not open destination file")
                            setStatus("Audio saved successfully.")
                        } catch (e: Exception) {
                            setStatus("Could not save audio: ${e.message ?: "unknown error"}")
                        } finally {
                            pendingOutput = null
                            pendingSaveUri = null
                        }
                    } else setStatus("Finished playing.")
                }
                override fun onError(utteranceId: String?) { setStatus("Speech failed. Please check that this language voice is installed.") }
            })
            setStatus("Speech engine ready. Enter text to begin.")
            refreshVoices()
        } else setStatus("Speech engine could not start. Check Android Text-to-speech settings.")
    }

    private fun refreshVoices() {
        if (!ready || !isAuthenticated) return
        val allVoices = tts.voices?.toList() ?: emptyList()
        voices = allVoices.filter { it.locale.language == selectedLocale.language }
            .sortedWith(compareBy<android.speech.tts.Voice> { it.isNetworkConnectionRequired }.thenBy { it.name })
        val labels = if (voices.isEmpty()) {
            listOf("System default voice · no matching voice listed")
        } else {
            voices.map {
                val quality = if (it.quality >= android.speech.tts.Voice.QUALITY_HIGH) "High quality" else "Standard"
                "${it.name} · $quality"
            }
        }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val available = tts.isLanguageAvailable(selectedLocale)
        if (available < TextToSpeech.LANG_AVAILABLE) {
            setStatus(if (selectedLocale.language == "km")
                "No Khmer voice is currently available in your phone's speech engine."
            else "No English voice is currently available in your phone's speech engine.")
        } else {
            tts.language = selectedLocale
            if (voices.isNotEmpty()) tts.voice = voices.first()
            setStatus("${labels.size} voice option(s) found. Ready.")
        }
    }

    private fun applyVoiceAndSpeed(): Boolean {
        if (!ready) { setStatus("Speech engine is still starting."); return false }
        val result = tts.setLanguage(selectedLocale)
        if (result < TextToSpeech.LANG_AVAILABLE) {
            setStatus("This language voice is not installed. Check Android Text-to-speech settings.")
            return false
        }
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            tts.voice = voices[voiceSpinner.selectedItemPosition]
        }
        tts.setSpeechRate(speed)
        return true
    }

    private fun speakText() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        pendingOutput = null
        pendingSaveUri = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview-${UUID.randomUUID()}")
        setStatus("Speaking now…")
    }

    private fun saveAudio() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }
        if (!applyVoiceAndSpeed()) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "TextToVoice-${currentUser().name}-${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(intent, 44)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            val text = textInput.text.toString().trim()
            if (text.isEmpty() || !applyVoiceAndSpeed()) return
            val output = File(cacheDir, "speech-${System.currentTimeMillis()}.wav")
            pendingOutput = output
            pendingSaveUri = data.data
            val id = "save-${UUID.randomUUID()}"
            val params = Bundle()
            val result = tts.synthesizeToFile(text, params, output, id)
            if (result != TextToSpeech.SUCCESS) {
                pendingOutput = null
                pendingSaveUri = null
                setStatus("Could not create the audio file with this voice.")
            } else setStatus("Generating audio file…")
        }
    }

    override fun onPause() {
        persistCurrentUserState()
        super.onPause()
    }

    override fun onDestroy() {
        persistCurrentUserState()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
