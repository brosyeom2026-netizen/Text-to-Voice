package com.texttovoice.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.ScrollingMovementMethod
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private lateinit var apiKeyInput: EditText
    private lateinit var apiStatusLabel: TextView
    private lateinit var languageSpinner: Spinner
    private lateinit var genderSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var emotionSpinner: Spinner
    private lateinit var emotionHintLabel: TextView
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var pitchLabel: TextView
    private lateinit var pitchBar: SeekBar
    private lateinit var countLabel: TextView
    private lateinit var playStopButton: Button
    private var isPlayingNow: Boolean = false

    private var ready = false
    private var selectedLocale: Locale = Locale.US
    // 0 = All Voices, 1 = Female, 2 = Male
    private var selectedGenderFilter: Int = 0
    // 0 = Neutral, 1 = Happy, 2 = Sad, 3 = Angry, 4 = Calm, 5 = Excited, 6 = Serious
    private var selectedEmotionIndex: Int = 0
    private var localVoices: List<Voice> = emptyList()
    private var pendingSaveUri: Uri? = null
    private var speed = 1.0f
    private var pitch = 1.0f

    // Google AI Studio Real Voice state
    private var apiKey: String = ""
    private var isApiKeyActive: Boolean = false
    private var mediaPlayer: MediaPlayer? = null
    private var lastAiAudioFile: File? = null
    private var lastAiCacheSignature: String = ""
    private var isGeneratingStudioAudio: Boolean = false

    data class StudioVoice(
        val id: String,
        val displayName: String,
        val gender: String
    )

    private val studioVoices = listOf(
        StudioVoice("Kore", "Female · Kore (Warm & Clear Studio Voice)", "Female"),
        StudioVoice("Aoede", "Female · Aoede (Expressive & Breezy)", "Female"),
        StudioVoice("Zephyr", "Female · Zephyr (Bright & Friendly)", "Female"),
        StudioVoice("Leda", "Female · Leda (Youthful & Sweet)", "Female"),
        StudioVoice("Callirrhoe", "Female · Callirrhoe (Gentle & Soft)", "Female"),
        StudioVoice("Autonoe", "Female · Autonoe (Calm & Natural)", "Female"),
        StudioVoice("Charon", "Male · Charon (Deep & Authoritative)", "Male"),
        StudioVoice("Puck", "Male · Puck (Upbeat & Energetic)", "Male"),
        StudioVoice("Fenrir", "Male · Fenrir (Strong & Dramatic)", "Male"),
        StudioVoice("Orus", "Male · Orus (Firm & Confident)", "Male"),
        StudioVoice("Enceladus", "Male · Enceladus (Breathy & Warm)", "Male"),
        StudioVoice("Iapetus", "Male · Iapetus (Clear Narrator)", "Male")
    )
    private var activeStudioVoices: List<StudioVoice> = studioVoices

    // Multi-chunk local fallback playback queue
    private data class SpeechChunk(
        val text: String,
        val rate: Float,
        val pitch: Float,
        val pauseAfterMs: Long
    )
    private val speechQueue = ArrayDeque<SpeechChunk>()
    private val tempChunkFiles = mutableListOf<File>()
    private var isSavingMultiChunk = false
    private var pendingSignature: String = ""

    // Secret 5-tap Admin Approval Generator trigger + PIN 2026 security
    private var copyrightTapCount = 0
    private var lastCopyrightTapTime = 0L
    private val adminSecurityPin = "2026"
    private val approvalSecretSalt = "YEOM_BROS_TTV_PRO_2026"

    data class ApprovedUserRecord(
        val requestId: String,
        val approvalKey: String,
        var note: String = "",
        val createdAt: String = ""
    )
    private val savedApprovedUsers = mutableListOf<ApprovedUserRecord>()

    private val blue = Color.rgb(31, 105, 220)
    private val darkBlue = Color.rgb(20, 68, 150)
    private val green = Color.rgb(22, 138, 72)
    private val dangerRed = Color.rgb(190, 55, 65)
    private val ink = Color.rgb(27, 39, 58)
    private val muted = Color.rgb(105, 119, 140)
    private val page = Color.rgb(244, 247, 252)
    private val border = Color.rgb(225, 232, 242)

    data class LanguageOption(
        val label: String,
        val shortName: String,
        val locale: Locale
    )

    private val languages = listOf(
        LanguageOption("Khmer · ខ្មែរ", "Khmer", Locale("km", "KH")),
        LanguageOption("English (US) · អង់គ្លេស", "English (US)", Locale.US),
        LanguageOption("English (UK) · អង់គ្លេស (UK)", "English (UK)", Locale.UK),
        LanguageOption("Thai · ไทย (ថៃ)", "Thai", Locale("th", "TH")),
        LanguageOption("Vietnamese · Tiếng Việt (វៀតណាម)", "Vietnamese", Locale("vi", "VN")),
        LanguageOption("Chinese (Mandarin) · 中文 (ចិន)", "Chinese", Locale.SIMPLIFIED_CHINESE),
        LanguageOption("Japanese · 日本語 (ជប៉ុន)", "Japanese", Locale.JAPAN),
        LanguageOption("Korean · 한국어 (កូរ៉េ)", "Korean", Locale.KOREA),
        LanguageOption("French · Français (បារាំង)", "French", Locale.FRANCE),
        LanguageOption("Spanish · Español (អេស្ប៉ាញ)", "Spanish", Locale("es", "ES")),
        LanguageOption("German · Deutsch (អាល្លឺម៉ង់)", "German", Locale.GERMANY),
        LanguageOption("Indonesian · Bahasa Indonesia", "Indonesian", Locale("id", "ID")),
        LanguageOption("Malay · Bahasa Melayu (ម៉ាឡេ)", "Malay", Locale("ms", "MY")),
        LanguageOption("Hindi · हिन्दी (ឥណ្ឌា)", "Hindi", Locale("hi", "IN")),
        LanguageOption("Arabic · العربية (អារ៉ាប់)", "Arabic", Locale("ar", "SA")),
        LanguageOption("Russian · Русский (រុស្ស៊ី)", "Russian", Locale("ru", "RU")),
        LanguageOption("Portuguese · Português (ព័រទុយហ្គាល់)", "Portuguese", Locale("pt", "BR")),
        LanguageOption("Italian · Italiano (អ៊ីតាលី)", "Italian", Locale.ITALY)
    )

    data class EmotionPreset(
        val title: String,
        val description: String,
        val aiStylePrompt: String,
        val speedProgress: Int,
        val pitchOffsetSteps: Int,
        val sentencePauseMs: Long,
        val commaPauseMs: Long,
        val pitchSwing: Float
    )

    private val emotions = listOf(
        EmotionPreset(
            title = "Neutral · ធម្មតា",
            description = "Balanced, natural human studio speaking tone.",
            aiStylePrompt = "Speak naturally, clearly, and warmly in a balanced human voice.",
            speedProgress = 5,
            pitchOffsetSteps = 0,
            sentencePauseMs = 260L,
            commaPauseMs = 120L,
            pitchSwing = 0.00f
        ),
        EmotionPreset(
            title = "Happy / Cheerful · សប្បាយរីករាយ",
            description = "Upbeat, warm, smiling, and lively human expression.",
            aiStylePrompt = "Speak with a cheerful, warm, smiling, upbeat, and joyful emotion.",
            speedProgress = 6,
            pitchOffsetSteps = 2,
            sentencePauseMs = 200L,
            commaPauseMs = 90L,
            pitchSwing = 0.07f
        ),
        EmotionPreset(
            title = "Sad / Emotional · កំសត់ / សោកសៅ",
            description = "Soft, heartfelt, emotional, and sorrowful storytelling.",
            aiStylePrompt = "Speak with deep sadness, heartfelt emotion, gentle sorrow, and thoughtful pauses.",
            speedProgress = 3,
            pitchOffsetSteps = -2,
            sentencePauseMs = 520L,
            commaPauseMs = 250L,
            pitchSwing = -0.05f
        ),
        EmotionPreset(
            title = "Angry / Strong · ខឹង / ម៉ឺងម៉ាត់",
            description = "Intense, forceful, serious, and dramatic delivery.",
            aiStylePrompt = "Speak with strong, serious, intense, firm, and dramatic emphasis.",
            speedProgress = 7,
            pitchOffsetSteps = -1,
            sentencePauseMs = 170L,
            commaPauseMs = 80L,
            pitchSwing = 0.06f
        ),
        EmotionPreset(
            title = "Calm / Storytelling · ស្ងប់ស្ងាត់ / និទានរឿង",
            description = "Gentle, soothing narration ideal for stories & sleep videos.",
            aiStylePrompt = "Speak in a calm, soothing, gentle, relaxing storytelling voice.",
            speedProgress = 4,
            pitchOffsetSteps = -1,
            sentencePauseMs = 420L,
            commaPauseMs = 200L,
            pitchSwing = 0.03f
        ),
        EmotionPreset(
            title = "Excited / Energetic · រំភើប / ស្វាហាប់",
            description = "High-energy, enthusiastic promo or viral video voice.",
            aiStylePrompt = "Speak with high energy, excitement, enthusiasm, and lively pacing.",
            speedProgress = 8,
            pitchOffsetSteps = 2,
            sentencePauseMs = 150L,
            commaPauseMs = 70L,
            pitchSwing = 0.09f
        ),
        EmotionPreset(
            title = "Serious / News · ផ្លូវការ / ព័ត៌មាន",
            description = "Professional, authoritative news broadcast tone.",
            aiStylePrompt = "Speak in a professional, serious, authoritative news anchor tone.",
            speedProgress = 5,
            pitchOffsetSteps = -1,
            sentencePauseMs = 320L,
            commaPauseMs = 150L,
            pitchSwing = 0.02f
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("yeom_bros_ttv_license_v1", Context.MODE_PRIVATE)
        apiKey = prefs.getString("google_ai_studio_api_key", "") ?: ""
        isApiKeyActive = prefs.getBoolean("google_ai_studio_active", false) && apiKey.isNotEmpty()
        loadApprovedUsers()

        window.statusBarColor = page
        window.navigationBarColor = Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        if (isDeviceActivated()) {
            openMainApp()
        } else {
            showActivationGateScreen()
        }
    }

    private fun loadApprovedUsers() {
        savedApprovedUsers.clear()
        val raw = prefs.getString("admin_saved_users_json", null)
        if (!raw.isNullOrEmpty()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    savedApprovedUsers.add(
                        ApprovedUserRecord(
                            requestId = obj.optString("requestId", ""),
                            approvalKey = obj.optString("approvalKey", ""),
                            note = obj.optString("note", ""),
                            createdAt = obj.optString("createdAt", "")
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun persistApprovedUsers() {
        val arr = JSONArray()
        for (u in savedApprovedUsers) {
            val obj = JSONObject().apply {
                put("requestId", u.requestId)
                put("approvalKey", u.approvalKey)
                put("note", u.note)
                put("createdAt", u.createdAt)
            }
            arr.put(obj)
        }
        prefs.edit().putString("admin_saved_users_json", arr.toString()).apply()
    }

    private fun getDeviceRequestId(): String {
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEVICE"
        val digest = MessageDigest.getInstance("SHA-256").digest("REQ|$androidId".toByteArray())
        val hex = digest.take(3).joinToString("") { "%02X".format(it) }
        return "REQ-$hex"
    }

    private fun computeApprovalKey(requestId: String): String {
        val cleanReq = requestId.trim().uppercase()
        val digest = MessageDigest.getInstance("SHA-256").digest("$cleanReq|$approvalSecretSalt".toByteArray())
        val hex = digest.take(4).joinToString("") { "%02X".format(it) }
        return "KEY-$hex"
    }

    private fun isDeviceActivated(): Boolean {
        val reqId = getDeviceRequestId()
        val savedKey = prefs.getString("approved_key", "") ?: ""
        return savedKey.isNotEmpty() && savedKey == computeApprovalKey(reqId)
    }

    private fun openMainApp() {
        buildMainAppUi()
        restoreSavedUserWork()
        if (!::tts.isInitialized) {
            tts = TextToSpeech(this, this)
        } else if (ready) {
            refreshVoices()
        }
    }

    // ==================== ACTIVATION GATE SCREEN ====================
    private fun showActivationGateScreen() {
        val requestId = getDeviceRequestId()

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(page)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }

        val brandCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = rounded(blue, 24)
        }
        brandCard.addView(TextView(this).apply {
            text = "TEXT TO VOICE · PRO VERSION"
            textSize = 11f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        })
        brandCard.addView(TextView(this).apply {
            text = "Admin Approval Required"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        })
        brandCard.addView(TextView(this).apply {
            text = "Send your Request ID to Admin to receive your Approval Code and unlock the app."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        root.addView(brandCard, matchWrap())

        val gateCard = card().apply {
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }

        gateCard.addView(TextView(this).apply {
            text = "Your Request ID"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })

        val reqBox = TextView(this).apply {
            text = requestId
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(232, 241, 255), 14, border)
        }
        gateCard.addView(reqBox, matchWrap())

        val copyReqBtn = Button(this).apply {
            text = "Copy Request ID"
            textSize = 14f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            background = rounded(Color.rgb(242, 246, 253), 14, border)
            minHeight = dp(44)
            setOnClickListener {
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Request ID", requestId))
                Toast.makeText(this@MainActivity, "Copied: $requestId", Toast.LENGTH_SHORT).show()
            }
        }
        gateCard.addView(copyReqBtn, matchWrap().apply { topMargin = dp(10) })

        gateCard.addView(TextView(this).apply {
            text = "Enter Approval Code"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(18), 0, dp(6))
        })

        val codeInput = EditText(this).apply {
            hint = "e.g. KEY-AE4F2BEE"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        gateCard.addView(codeInput, matchWrap())

        val gateStatus = TextView(this).apply {
            text = ""
            textSize = 12f
            setTextColor(dangerRed)
            setPadding(0, dp(8), 0, dp(4))
        }
        gateCard.addView(gateStatus, matchWrap())

        val activateBtn = actionButton("Activate & Unlock App", blue)
        activateBtn.setOnClickListener {
            val entered = codeInput.text.toString().trim().uppercase()
            val expected = computeApprovalKey(requestId)
            if (entered.isEmpty()) {
                gateStatus.text = "Please paste the Approval Code from Admin."
                return@setOnClickListener
            }
            if (entered == expected) {
                prefs.edit().putString("approved_key", entered).apply()
                Toast.makeText(this, "Approved! Welcome to Text to Voice.", Toast.LENGTH_SHORT).show()
                openMainApp()
            } else {
                gateStatus.text = "Invalid Approval Code for $requestId."
            }
        }
        gateCard.addView(activateBtn, matchWrap().apply { topMargin = dp(6) })

        root.addView(gateCard, matchWrap().apply { topMargin = dp(18) })
        root.addView(createCopyrightFooter(), matchWrap().apply { topMargin = dp(18) })

        scroll.addView(root)
        setContentView(scroll)
        applySystemBarInsets(scroll)
    }

    // ==================== 5-TAP COPYRIGHT -> PIN 2026 -> ADMIN APPROVAL & USER ID MANAGER ====================
    private fun createCopyrightFooter(): TextView {
        return TextView(this).apply {
            text = "Copyright by : YEOM BROS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val now = System.currentTimeMillis()
                if (now - lastCopyrightTapTime > 2000L) {
                    copyrightTapCount = 0
                }
                lastCopyrightTapTime = now
                copyrightTapCount++
                if (copyrightTapCount >= 5) {
                    copyrightTapCount = 0
                    promptPin2026BeforeAdmin()
                }
            }
        }
    }

    private fun promptPin2026BeforeAdmin() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(14), dp(22), dp(6))
        }
        container.addView(TextView(this).apply {
            text = "Enter Admin Security PIN to unlock Approval Generator & Saved User IDs:"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        })
        val pinInput = EditText(this).apply {
            hint = "Enter PIN"
            textSize = 18f
            setTextColor(ink)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, 12, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        container.addView(pinInput, matchWrap())

        AlertDialog.Builder(this)
            .setTitle("YEOM BROS · Security Check")
            .setView(container)
            .setPositiveButton("Verify PIN") { _, _ ->
                val enteredPin = pinInput.text.toString().trim()
                if (enteredPin == adminSecurityPin) {
                    showAdminApprovalGeneratorDialog()
                } else {
                    Toast.makeText(this, "Wrong Security PIN!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAdminApprovalGeneratorDialog() {
        val outerScroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(12))
        }

        container.addView(TextView(this).apply {
            text = "Enter the user's Request ID (e.g., REQ-1A2B3C) to generate & save their Approval Code:"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        })

        val reqInput = EditText(this).apply {
            hint = "REQ-1A2B3C"
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.WHITE, 12, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        container.addView(reqInput, matchWrap())

        val noteInput = EditText(this).apply {
            hint = "User Name / Note (optional, e.g., Sokha)"
            textSize = 14f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.WHITE, 12, border)
            setSingleLine(true)
        }
        container.addView(noteInput, matchWrap().apply { topMargin = dp(8) })

        val generatedKeyDisplay = TextView(this).apply {
            text = "KEY-XXXXXXXX"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkBlue)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(232, 241, 255), 12, border)
        }
        container.addView(generatedKeyDisplay, matchWrap().apply { topMargin = dp(10) })

        // Saved User IDs container (dynamically refreshed when copied or deleted)
        val savedListTitle = TextView(this).apply {
            text = "Saved Approved User IDs (${savedApprovedUsers.size})"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(18), 0, dp(8))
        }
        val savedUsersListLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        fun rebuildSavedUsersList() {
            savedListTitle.text = "Saved Approved User IDs (${savedApprovedUsers.size})"
            savedUsersListLayout.removeAllViews()

            if (savedApprovedUsers.isEmpty()) {
                savedUsersListLayout.addView(TextView(this).apply {
                    text = "No User IDs saved yet. When you tap 'Copy & Save User ID', it will appear here."
                    textSize = 12f
                    setTextColor(muted)
                    setPadding(dp(4), dp(4), dp(4), dp(8))
                })
                return
            }

            for (record in savedApprovedUsers.toList()) {
                val rowCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(10), dp(10))
                    background = rounded(Color.rgb(248, 250, 254), 12, border)
                }

                val infoCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                }
                val titleLine = if (record.note.isNotEmpty()) {
                    "${record.requestId}  (${record.note})"
                } else {
                    record.requestId
                }
                infoCol.addView(TextView(this).apply {
                    text = titleLine
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(ink)
                })
                infoCol.addView(TextView(this).apply {
                    text = "Code: ${record.approvalKey}" + if (record.createdAt.isNotEmpty()) " · ${record.createdAt}" else ""
                    textSize = 11f
                    setTextColor(darkBlue)
                })
                rowCard.addView(infoCol, LinearLayout.LayoutParams(0, -2, 1f))

                // Copy again button
                val reCopyBtn = Button(this).apply {
                    text = "Copy"
                    textSize = 11f
                    isAllCaps = false
                    setTextColor(blue)
                    background = rounded(Color.rgb(232, 241, 255), 8)
                    minWidth = dp(48)
                    minHeight = dp(34)
                    setPadding(dp(8), 0, dp(8), 0)
                    setOnClickListener {
                        val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cb.setPrimaryClip(ClipData.newPlainText("Approval Code", record.approvalKey))
                        Toast.makeText(this@MainActivity, "Copied ${record.approvalKey}", Toast.LENGTH_SHORT).show()
                    }
                }
                rowCard.addView(reCopyBtn, LinearLayout.LayoutParams(-2, dp(34)))
                rowCard.addView(Space(this), LinearLayout.LayoutParams(dp(6), 1))

                // Delete User ID button
                val deleteBtn = Button(this).apply {
                    text = "Delete"
                    textSize = 11f
                    isAllCaps = false
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    background = rounded(dangerRed, 8)
                    minWidth = dp(54)
                    minHeight = dp(34)
                    setPadding(dp(8), 0, dp(8), 0)
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Delete User ID?")
                            .setMessage("Remove ${record.requestId} from saved User IDs?\n\n(If this is the current device, it will also lock the app until re-approved.)")
                            .setPositiveButton("Delete") { _, _ ->
                                savedApprovedUsers.removeAll { it.requestId.equals(record.requestId, ignoreCase = true) }
                                persistApprovedUsers()
                                // If Admin deletes this current device's Request ID, revoke local activation immediately
                                if (record.requestId.equals(getDeviceRequestId(), ignoreCase = true)) {
                                    prefs.edit().remove("approved_key").apply()
                                }
                                rebuildSavedUsersList()
                                Toast.makeText(this@MainActivity, "Deleted ${record.requestId}", Toast.LENGTH_SHORT).show()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
                rowCard.addView(deleteBtn, LinearLayout.LayoutParams(-2, dp(34)))

                savedUsersListLayout.addView(rowCard, matchWrap().apply { topMargin = dp(6) })
            }
        }

        val copyAndSaveBtn = Button(this).apply {
            text = "Copy & Save User ID"
            textSize = 15f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(blue, 12)
            minHeight = dp(48)
            setOnClickListener {
                val rawReq = reqInput.text.toString().trim().uppercase()
                if (rawReq.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Enter a Request ID first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val formattedReq = if (rawReq.startsWith("REQ-")) rawReq else "REQ-$rawReq"
                val key = computeApprovalKey(formattedReq)
                val noteText = noteInput.text.toString().trim()
                val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

                // Copy Approval Code to clipboard
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("Approval Code", key))

                // Save User ID record so Admin can view or delete it anytime
                savedApprovedUsers.removeAll { it.requestId.equals(formattedReq, ignoreCase = true) }
                savedApprovedUsers.add(
                    0,
                    ApprovedUserRecord(
                        requestId = formattedReq,
                        approvalKey = key,
                        note = noteText,
                        createdAt = dateStr
                    )
                )
                persistApprovedUsers()
                rebuildSavedUsersList()

                Toast.makeText(this@MainActivity, "Copied $key & Saved $formattedReq!", Toast.LENGTH_SHORT).show()
            }
        }
        container.addView(copyAndSaveBtn, matchWrap().apply { topMargin = dp(10) })

        reqInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val raw = s?.toString()?.trim()?.uppercase() ?: ""
                if (raw.isEmpty()) {
                    generatedKeyDisplay.text = "KEY-XXXXXXXX"
                } else {
                    val formattedReq = if (raw.startsWith("REQ-")) raw else "REQ-$raw"
                    generatedKeyDisplay.text = computeApprovalKey(formattedReq)
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        container.addView(savedListTitle)
        container.addView(savedUsersListLayout, matchWrap())
        rebuildSavedUsersList()

        outerScroll.addView(container)

        AlertDialog.Builder(this)
            .setTitle("Admin Approval Generator")
            .setView(outerScroll)
            .setPositiveButton("Close") { _, _ ->
                if (!isDeviceActivated()) {
                    showActivationGateScreen()
                }
            }
            .show()
    }

    // ==================== GOOGLE AI STUDIO REAL VOICE API ====================
    private fun verifyAndActivateApiKey(rawKey: String) {
        val trimmed = rawKey.trim()
        if (trimmed.isEmpty()) {
            isApiKeyActive = false
            apiKey = ""
            prefs.edit().remove("google_ai_studio_api_key").putBoolean("google_ai_studio_active", false).apply()
            updateApiKeyStatusUi()
            refreshVoices()
            return
        }

        apiStatusLabel.setTextColor(blue)
        apiStatusLabel.text = "Verifying Google AI Studio API key…"

        Thread {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=$trimmed")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                }
                val code = conn.responseCode
                conn.disconnect()

                runOnUiThread {
                    if (code in 200..299) {
                        apiKey = trimmed
                        isApiKeyActive = true
                        prefs.edit()
                            .putString("google_ai_studio_api_key", apiKey)
                            .putBoolean("google_ai_studio_active", true)
                            .apply()
                        updateApiKeyStatusUi()
                        refreshVoices()
                        setStatus("Google AI Studio Real Voices ACTIVE! Ready to speak.")
                        Toast.makeText(this, "API Key Active! Real Studio Voices unlocked.", Toast.LENGTH_SHORT).show()
                    } else {
                        isApiKeyActive = false
                        prefs.edit().putBoolean("google_ai_studio_active", false).apply()
                        apiStatusLabel.setTextColor(dangerRed)
                        apiStatusLabel.text = "Invalid API Key (HTTP $code). Check your key from aistudio.google.com."
                        refreshVoices()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    isApiKeyActive = false
                    apiStatusLabel.setTextColor(dangerRed)
                    apiStatusLabel.text = "Connection error: ${e.message ?: "check internet"}"
                }
            }
        }.start()
    }

    private fun updateApiKeyStatusUi() {
        if (!::apiStatusLabel.isInitialized) return
        if (isApiKeyActive && apiKey.isNotEmpty()) {
            apiStatusLabel.setTextColor(green)
            apiStatusLabel.text = "● ACTIVE · Google AI Studio Real Human Voices Enabled"
        } else {
            apiStatusLabel.setTextColor(muted)
            apiStatusLabel.text = "○ Offline Mode · Paste your Google AI Studio API key above for real human voices"
        }
    }

    private fun sanitizeTextForTts(raw: String): String {
        // Strip emojis and pictographs that trigger HTTP 500 on Gemini TTS models, while keeping Khmer/Latin/CJK/Arabic scripts intact
        val sb = StringBuilder()
        var i = 0
        while (i < raw.length) {
            val cp = raw.codePointAt(i)
            val charCount = Character.charCount(cp)
            val isEmoji = (cp in 0x1F300..0x1FAFF) ||
                (cp in 0x2600..0x27BF) ||
                (cp in 0xFE00..0xFE0F) ||
                (cp == 0x200D)
            if (!isEmoji) {
                sb.appendCodePoint(cp)
            }
            i += charCount
        }
        return sb.toString().replace(Regex("[ \t]+"), " ").trim()
    }

    // Everything that decides how the audio sounds. Cached audio is reused only if this still matches.
    private fun selectionSignature(text: String): String {
        val studio = isApiKeyActive && apiKey.isNotEmpty()
        val voiceId = if (studio) {
            (activeStudioVoices.getOrNull(voiceSpinner.selectedItemPosition) ?: activeStudioVoices.first()).id
        } else {
            localVoices.getOrNull(voiceSpinner.selectedItemPosition)?.name ?: "default"
        }
        val base = "${if (studio) "studio" else "local"}|$voiceId|g$selectedGenderFilter|e$selectedEmotionIndex|" +
            "${selectedLocale.toLanguageTag()}|${"%.2f".format(Locale.US, speed)}|"
        val tone = if (studio) "" else "${"%.2f".format(Locale.US, pitch)}|"
        return base + tone + text.trim()
    }

    private fun isCachedAudioCurrent(text: String): Boolean {
        val f = getActiveAudioFile()
        return f.exists() && f.length() > 44 && lastAiCacheSignature.isNotEmpty() &&
            lastAiCacheSignature == selectionSignature(text)
    }

    private fun updatePlayStopButtonUi(playing: Boolean) {
        isPlayingNow = playing
        if (!::playStopButton.isInitialized) return
        runOnUiThread {
            if (playing) {
                playStopButton.text = "■   Stop"
                playStopButton.background = rounded(dangerRed, 16)
            } else {
                playStopButton.text = "▶   Play Audio"
                playStopButton.background = rounded(green, 16)
            }
        }
    }

    private fun getActiveAudioFile(): File = File(cacheDir, "current_generated_voice.wav")

    private fun deleteOldGeneratedAudio() {
        stopMediaPlayer()
        try {
            lastAiAudioFile?.delete()
            val f = getActiveAudioFile()
            if (f.exists()) f.delete()
        } catch (_: Exception) {
        }
        lastAiAudioFile = null
        lastAiCacheSignature = ""
    }

    private fun generateStudioAudio(
        text: String,
        saveToUri: Uri? = null
    ) {
        if (isGeneratingStudioAudio) {
            setStatus("Please wait, generating new audio…")
            return
        }
        val voiceObj = activeStudioVoices.getOrNull(voiceSpinner.selectedItemPosition) ?: activeStudioVoices.first()
        val emotionObj = emotions[selectedEmotionIndex.coerceIn(emotions.indices)]
        val langName = selectedLanguageName()

        val cleanedText = sanitizeTextForTts(text)
        if (cleanedText.isEmpty()) {
            setStatus("Please enter readable words (emojis alone cannot be spoken).")
            return
        }

        // Always delete and replace old audio before generating new voice
        deleteOldGeneratedAudio()

        val signature = selectionSignature(text)
        val paceInstruction = when {
            speed < 0.85f -> "slowly and deliberately"
            speed > 1.15f -> "at a brisk, fast pace"
            else -> "at a natural conversational pace"
        }

        val styledPrompt = "Read the following $langName text aloud $paceInstruction. ${emotionObj.aiStylePrompt}\n\n$cleanedText"

        isGeneratingStudioAudio = true
        setStatus("Generating new ${voiceObj.gender} voice (${voiceObj.id}) — replacing old audio…")

        Thread {
            val modelsToTry = listOf(
                "gemini-3.8-flash-tts",
                "gemini-3.8-flash-lite-tts",
                "gemini-2.5-pro-preview-tts",
                "gemini-2.5-flash-preview-tts"
            )
            var audioBytes: ByteArray? = null
            var lastError = "Unknown API error"

            for (modelId in modelsToTry) {
                var attempts = 0
                var permanentError = false
                while (attempts < 2 && audioBytes == null && !permanentError) {
                    attempts++
                    try {
                        val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=$apiKey")
                        val payload = JSONObject().apply {
                            put("contents", JSONArray().put(JSONObject().apply {
                                put("parts", JSONArray().put(JSONObject().put("text", styledPrompt)))
                            }))
                            put("generationConfig", JSONObject().apply {
                                put("responseModalities", JSONArray().put("AUDIO"))
                                put("speechConfig", JSONObject().apply {
                                    put("voiceConfig", JSONObject().apply {
                                        put("prebuiltVoiceConfig", JSONObject().apply {
                                            put("voiceName", voiceObj.id)
                                        })
                                    })
                                })
                            })
                        }

                    val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        doOutput = true
                        connectTimeout = 20000
                        readTimeout = 45000
                    }
                    conn.outputStream.use { os ->
                        os.write(payload.toString().toByteArray(Charsets.UTF_8))
                    }

                    val code = conn.responseCode
                    if (code in 200..299) {
                        val respStr = conn.inputStream.bufferedReader().use { it.readText() }
                        val respJson = JSONObject(respStr)
                        val candidates = respJson.optJSONArray("candidates")
                        val parts = candidates?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts")

                        if (parts != null) {
                            for (i in 0 until parts.length()) {
                                val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData")
                                val b64 = inlineData?.optString("data", "") ?: ""
                                if (b64.isNotEmpty()) {
                                    val rawDecoded = Base64.decode(b64, Base64.DEFAULT)
                                    audioBytes = if (rawDecoded.size >= 4 &&
                                        rawDecoded[0] == 'R'.code.toByte() &&
                                        rawDecoded[1] == 'I'.code.toByte() &&
                                        rawDecoded[2] == 'F'.code.toByte() &&
                                        rawDecoded[3] == 'F'.code.toByte()
                                    ) {
                                        rawDecoded
                                    } else {
                                        wrapPcmAsWav(rawDecoded, 24000, 1, 16)
                                    }
                                    break
                                }
                            }
                        }
                        if (audioBytes != null) break
                    } else {
                        val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                        lastError = "$modelId HTTP $code: ${extractApiErrorMessage(errBody)}"
                        // Retrying only helps for rate limits / server errors
                        if (code != 429 && code < 500) permanentError = true
                    }
                    conn.disconnect()
                    } catch (e: Exception) {
                        lastError = e.message ?: "Network error"
                    }
                    if (audioBytes == null && attempts < 2 && !permanentError) {
                        try { Thread.sleep(700L) } catch (_: Exception) {}
                    }
                }
                if (audioBytes != null) break
            }

            runOnUiThread {
                isGeneratingStudioAudio = false
                val finalBytes = audioBytes
                if (finalBytes == null) {
                    setStatus("Google AI Studio error: $lastError")
                    return@runOnUiThread
                }

                try {
                    val activeWav = getActiveAudioFile()
                    if (activeWav.exists()) activeWav.delete()
                    FileOutputStream(activeWav).use { it.write(finalBytes) }
                    lastAiAudioFile = activeWav
                    lastAiCacheSignature = signature

                    if (saveToUri != null) {
                        contentResolver.openOutputStream(saveToUri)?.use { out ->
                            out.write(finalBytes)
                        } ?: throw IllegalStateException("Cannot write to selected file")
                        setStatus("Real Studio WAV audio saved (${voiceObj.id} · ${voiceObj.gender})!")
                    } else {
                        playWavFile(activeWav, "${voiceObj.id} (${voiceObj.gender})")
                    }
                } catch (e: Exception) {
                    setStatus("Audio playback/save error: ${e.message}")
                }
            }
        }.start()
    }

    private fun extractApiErrorMessage(errJson: String): String {
        return try {
            JSONObject(errJson).optJSONObject("error")?.optString("message") ?: errJson.take(120)
        } catch (_: Exception) {
            errJson.take(120)
        }
    }

    private fun wrapPcmAsWav(pcmData: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = (channels * (bitsPerSample / 8)).toShort()
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(36 + pcmData.size)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1)
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign)
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()
        return header + pcmData
    }

    private fun playWavFile(file: File, label: String) {
        stopMediaPlayer()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)

            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setVolume(1.0f, 1.0f)
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { player ->
                player.seekTo(0)
                player.start()
                updatePlayStopButtonUi(true)
                setStatus("Playing Audio ($label)…")
            }
            mp.setOnCompletionListener { player ->
                try { player.seekTo(0) } catch (_: Exception) {}
                updatePlayStopButtonUi(false)
                setStatus("Finished playing ($label). Tap 'Play Audio' to listen again or 'Save Audio'.")
            }
            mp.setOnErrorListener { _, what, extra ->
                updatePlayStopButtonUi(false)
                setStatus("Audio playback error ($what/$extra).")
                true
            }
            mediaPlayer = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            updatePlayStopButtonUi(false)
            setStatus("Playback error: ${e.message ?: "unknown"}")
        }
    }

    private fun stopMediaPlayer() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
        } catch (_: Exception) {
        }
        mediaPlayer = null
        updatePlayStopButtonUi(false)
    }

    // ==================== LOCAL FALLBACK GENDER & EMOTION ENGINE ====================
    private fun detectVoiceGender(voice: Voice): String {
        val raw = (voice.name + " " + voice.features.joinToString(" ")).lowercase(Locale.US)
        val femaleTokens = listOf(
            "sfg", "tpf", "sfb", "sfc", "sfd",
            "iob", "iog", "gba", "gbc", "rjs", "khm-x-khm", "tha-x-tha",
            "vie-x-vie", "cmn-cn-x-ccc", "cmn-cn-x-ssa", "jpn-jp-x-jab",
            "kor-kr-x-ism", "fra-fr-x-fra", "spa-es-x-ana", "deu-de-x-deb",
            "ind-id-x-idc", "msa-my-x-msc", "hin-in-x-hia", "rus-ru-x-ruc"
        )
        val maleTokens = listOf(
            "iom", "iol", "tpd", "sfa", "gbb", "gbd",
            "cmn-cn-x-ccd", "cmn-cn-x-cce", "jpn-jp-x-jac", "jpn-jp-x-jad",
            "kor-kr-x-kob", "kor-kr-x-koc", "fra-fr-x-frb", "fra-fr-x-frd",
            "spa-es-x-eea", "deu-de-x-dea", "deu-de-x-ded", "ind-id-x-idd",
            "msa-my-x-msd", "hin-in-x-hib", "hin-in-x-hid", "rus-ru-x-rud",
            "vie-x-gmm", "tha-x-thb"
        )
        val words = raw.split(Regex("[^a-z0-9]+")).toSet()
        fun hit(entry: String) = if (entry.contains('-')) raw.contains(entry) else entry in words
        if (words.any { it == "female" || it == "woman" || it == "girl" }) return "Female"
        if (words.any { it == "male" || it == "man" || it == "boy" }) return "Male"
        if (maleTokens.any { hit(it) }) return "Male"
        if (femaleTokens.any { hit(it) }) return "Female"
        return "Standard"
    }

    private fun isBaseVoiceFemale(): Boolean {
        if (localVoices.isNotEmpty() && voiceSpinner.selectedItemPosition in localVoices.indices) {
            val v = localVoices[voiceSpinner.selectedItemPosition]
            val g = detectVoiceGender(v)
            if (g == "Male") return false
            if (g == "Female") return true
        }
        return true
    }

    private fun pitchFromProgress(progress: Int): Float {
        return 0.55f + progress.coerceIn(0, 14) * 0.05f
    }

    private fun buildExpressiveChunks(fullText: String): List<SpeechChunk> {
        val preset = emotions[selectedEmotionIndex.coerceIn(emotions.indices)]
        val rawParts = Regex("[^.!?។៕,\\n]+[.!?។៕,\\n]*")
            .findAll(fullText)
            .map { it.value.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val parts = if (rawParts.isEmpty()) listOf(fullText.trim()) else rawParts
        val result = mutableListOf<SpeechChunk>()

        for ((index, part) in parts.withIndex()) {
            val isQuestion = part.endsWith("?")
            val isExclamation = part.endsWith("!") || part.endsWith("៕")
            val isComma = part.endsWith(",")
            val isSentenceEnd = part.endsWith(".") || part.endsWith("។") || isQuestion || isExclamation

            var chunkRate = speed
            var chunkPitch = pitch

            val wave = if (index % 2 == 0) preset.pitchSwing else -preset.pitchSwing * 0.6f
            chunkPitch += wave

            if (isQuestion) {
                chunkPitch += 0.09f
                chunkRate *= 0.96f
            } else if (isExclamation) {
                chunkPitch += 0.08f
                chunkRate *= 1.05f
            } else if (isSentenceEnd && selectedEmotionIndex == 2) {
                chunkPitch -= 0.05f
                chunkRate *= 0.94f
            }

            if (selectedGenderFilter == 2 && isBaseVoiceFemale()) {
                chunkPitch = chunkPitch.coerceIn(0.52f, 0.80f)
            } else {
                chunkPitch = chunkPitch.coerceIn(0.52f, 1.55f)
            }

            val pauseMs = when {
                isComma -> preset.commaPauseMs
                isSentenceEnd -> preset.sentencePauseMs
                else -> 140L
            }

            result.add(
                SpeechChunk(
                    text = part,
                    rate = chunkRate.coerceIn(0.4f, 2.2f),
                    pitch = chunkPitch,
                    pauseAfterMs = pauseMs
                )
            )
        }
        return result
    }

    // ==================== MAIN TEXT-TO-VOICE UI ====================
    private fun saveUserWork() {
        if (!::textInput.isInitialized) return
        prefs.edit()
            .putInt("saved_lang", languageSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_gender", genderSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_emotion", emotionSpinner.selectedItemPosition.coerceAtLeast(0))
            .putInt("saved_speed", speedBar.progress)
            .putInt("saved_pitch", pitchBar.progress)
            .putString("saved_text", textInput.text.toString())
            .apply()
    }

    private fun restoreSavedUserWork() {
        val langIdx = prefs.getInt("saved_lang", 0).coerceIn(languages.indices)
        languageSpinner.setSelection(langIdx)
        selectedLocale = languages[langIdx].locale

        val genderIdx = prefs.getInt("saved_gender", 0).coerceIn(0, 2)
        genderSpinner.setSelection(genderIdx)
        selectedGenderFilter = genderIdx

        val emotionIdx = prefs.getInt("saved_emotion", 0).coerceIn(emotions.indices)
        emotionSpinner.setSelection(emotionIdx)
        selectedEmotionIndex = emotionIdx
        emotionHintLabel.text = emotions[emotionIdx].description

        val prog = prefs.getInt("saved_speed", 5).coerceIn(0, 15)
        speedBar.progress = prog
        speed = 0.5f + prog * 0.1f
        updateSpeedLabel()

        val pProg = prefs.getInt("saved_pitch", 9).coerceIn(0, 14)
        pitchBar.progress = pProg
        pitch = pitchFromProgress(pProg)
        updatePitchLabel()

        val savedText = prefs.getString("saved_text", "") ?: ""
        textInput.setText(savedText)
        textInput.setSelection(textInput.text.length)
        countLabel.text = "${textInput.text.length} characters"
    }

    private fun updateSpeedLabel() {
        val label = when {
            speed < 0.9f -> "Slow"
            speed > 1.1f -> "Fast"
            else -> "Normal"
        }
        speedLabel.text = "$label · %.1f×".format(speed)
    }

    private fun updatePitchLabel() {
        val tone = when {
            pitch <= 0.78f -> "Deep Male Voice Tone"
            pitch <= 0.92f -> "Warm Male Tone"
            pitch >= 1.08f -> "Bright Female Tone"
            else -> "Natural Female / Standard Tone"
        }
        pitchLabel.text = "$tone · %.2f×".format(pitch)
    }

    private fun buildMainAppUi() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            setBackgroundColor(page)
        }
        val pageColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }

        // Top Brand Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(blue, 24)
        }
        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topHeaderRow.addView(TextView(this).apply {
            text = "TEXT TO VOICE"
            textSize = 12f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(220, 234, 255))
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))

        topHeaderRow.addView(TextView(this).apply {
            text = "Pro Verified"
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = rounded(darkBlue, 12)
        })
        header.addView(topHeaderRow, matchWrap())

        header.addView(TextView(this).apply {
            text = "Give your words a voice."
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(7), 0, dp(5))
        })
        header.addView(TextView(this).apply {
            text = "Paste your Google AI Studio API Key to unlock real human Male & Female voices in 18 languages."
            textSize = 14f
            setTextColor(Color.rgb(235, 242, 255))
        })
        pageColumn.addView(header, matchWrap())

        // API KEY BOX
        pageColumn.addView(sectionTitle("Google AI Studio API Key (Real Voices)"))
        val apiCard = card()

        apiKeyInput = EditText(this).apply {
            hint = "Paste API Key here (AIzaSy...)"
            setText(apiKey)
            textSize = 14f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(248, 250, 254), 12, border)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        apiCard.addView(apiKeyInput, matchWrap())

        val apiButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
        }

        val pasteApiBtn = Button(this).apply {
            text = "Paste Key"
            textSize = 13f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(blue)
            background = rounded(Color.rgb(232, 241, 255), 12)
            minHeight = dp(42)
            setOnClickListener {
                val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cb.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this@MainActivity)?.toString()?.trim() ?: ""
                    if (pasted.isNotEmpty()) {
                        apiKeyInput.setText(pasted)
                        verifyAndActivateApiKey(pasted)
                    }
                } else {
                    Toast.makeText(this@MainActivity, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val activeApiBtn = Button(this).apply {
            text = "Active Real Voices"
            textSize = 13f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(green, 12)
            minHeight = dp(42)
            setOnClickListener {
                verifyAndActivateApiKey(apiKeyInput.text.toString())
            }
        }

        val clearApiBtn = Button(this).apply {
            text = "Clear"
            textSize = 13f
            isAllCaps = false
            setTextColor(dangerRed)
            background = rounded(Color.rgb(255, 239, 240), 12)
            minHeight = dp(42)
            setOnClickListener {
                apiKeyInput.text.clear()
                verifyAndActivateApiKey("")
            }
        }

        apiButtonsRow.addView(pasteApiBtn, LinearLayout.LayoutParams(0, dp(42), 1f))
        apiButtonsRow.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        apiButtonsRow.addView(activeApiBtn, LinearLayout.LayoutParams(0, dp(42), 1.4f))
        apiButtonsRow.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        apiButtonsRow.addView(clearApiBtn, LinearLayout.LayoutParams(0, dp(42), 0.8f))
        apiCard.addView(apiButtonsRow, matchWrap())

        apiStatusLabel = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, 0)
        }
        apiCard.addView(apiStatusLabel, matchWrap())
        updateApiKeyStatusUi()
        pageColumn.addView(apiCard, matchWrap())

        // 1. Language
        pageColumn.addView(sectionTitle("1. Choose your language (${languages.size} languages)"))
        val languageCard = card()
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            languages.map { it.label }
        )
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedLocale = languages[position.coerceIn(languages.indices)].locale
                saveUserWork()
                refreshVoices()
            }
        }
        languageCard.addView(languageSpinner, matchWrap())
        pageColumn.addView(languageCard, matchWrap())

        // 2. Female / Male Voice & Feel
        pageColumn.addView(sectionTitle("2. Voice gender & speaking feel"))
        val voiceCard = card()

        voiceCard.addView(TextView(this).apply {
            text = "Voice Gender (Male / Female)"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, 0, 0, dp(4))
        })

        genderSpinner = Spinner(this)
        genderSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("All Voices (Male & Female)", "Female Voice (ស្រី)", "Male Voice (ប្រុស)")
        )
        genderSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val changed = position != selectedGenderFilter
                selectedGenderFilter = position
                refreshVoices()
                // Only auto-tune sliders on a real user change, not the initial/restore callback
                if (changed) applyGenderAndEmotionTone()
                saveUserWork()
            }
        }
        voiceCard.addView(genderSpinner, matchWrap())

        voiceCard.addView(TextView(this).apply {
            text = "Speaking Feel / Emotion (អារម្មណ៍នៃការនិយាយ)"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, dp(12), 0, dp(4))
        })

        emotionSpinner = Spinner(this)
        emotionSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            emotions.map { it.title }
        )
        emotionHintLabel = TextView(this).apply {
            text = emotions[0].description
            textSize = 12f
            setTextColor(blue)
            setPadding(0, dp(4), 0, dp(4))
        }
        emotionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val changed = position != selectedEmotionIndex
                selectedEmotionIndex = position
                emotionHintLabel.text = emotions[position].description
                if (changed) applyGenderAndEmotionTone()
                saveUserWork()
            }
        }
        voiceCard.addView(emotionSpinner, matchWrap())
        voiceCard.addView(emotionHintLabel, matchWrap())

        voiceCard.addView(TextView(this).apply {
            text = "Select Voice Model"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, dp(10), 0, dp(4))
        })

        voiceSpinner = Spinner(this)
        voiceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {}
        }
        voiceCard.addView(voiceSpinner, matchWrap())
        pageColumn.addView(voiceCard, matchWrap())

        // 3. Text input
        pageColumn.addView(sectionTitle("3. Write your text"))
        val textCard = card()
        textInput = EditText(this).apply {
            hint = "Type or paste your text in Khmer, English, or any selected language…"
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(150, 160, 176))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(248, 250, 254), 14, border)
            setSingleLine(false)
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            overScrollMode = View.OVER_SCROLL_ALWAYS
            movementMethod = ScrollingMovementMethod.getInstance()
            setOnTouchListener { v, event ->
                if (v.hasFocus()) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if ((event.action and MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP) {
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                }
                false
            }
        }
        textCard.addView(textInput, LinearLayout.LayoutParams(-1, dp(190)))

        val textTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(2))
        }
        val pasteButton = Button(this).apply {
            text = "Paste"
            textSize = 13f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.rgb(232, 241, 255), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this@MainActivity)
                    if (!pasted.isNullOrEmpty()) {
                        val start = textInput.selectionStart.coerceAtLeast(0)
                        val end = textInput.selectionEnd.coerceAtLeast(0)
                        textInput.text.replace(minOf(start, end), maxOf(start, end), pasted)
                        setStatus("Text pasted from clipboard.")
                    }
                } else setStatus("Clipboard is empty.")
            }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            textSize = 13f
            isAllCaps = false
            setTextColor(dangerRed)
            background = rounded(Color.rgb(255, 239, 240), 12)
            minHeight = dp(42)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                textInput.text.clear()
                setStatus("Text cleared.")
            }
        }
        textTools.addView(pasteButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textTools.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        textTools.addView(clearButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        textCard.addView(textTools, matchWrap())

        countLabel = TextView(this).apply {
            text = "0 characters"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        textCard.addView(countLabel, matchWrap())
        textInput.addTextChangedListener(SimpleTextWatcher {
            countLabel.text = "${textInput.text.length} characters"
            saveUserWork()
        })
        pageColumn.addView(textCard, matchWrap())

        // 4. Fine-tune speed & tone
        pageColumn.addView(sectionTitle("4. Fine-tune speed & tone"))
        val speedCard = card()
        speedLabel = TextView(this).apply {
            text = "Normal · 1.0×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        speedCard.addView(speedLabel)
        speedBar = SeekBar(this).apply { max = 15; progress = 5 }
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = 0.5f + progress * 0.1f
                updateSpeedLabel()
                if (fromUser) saveUserWork()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(speedBar, matchWrap())

        pitchLabel = TextView(this).apply {
            text = "Natural Tone · 1.00×"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(12), 0, 0)
        }
        speedCard.addView(pitchLabel)
        pitchBar = SeekBar(this).apply { max = 14; progress = 9 }
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                pitch = pitchFromProgress(progress)
                updatePitchLabel()
                if (fromUser) saveUserWork()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        speedCard.addView(pitchBar, matchWrap())
        speedCard.addView(TextView(this).apply {
            text = "Speed controls both AI Studio & Offline voices; Pitch adjusts offline fallback voices."
            textSize = 12f
            setTextColor(muted)
        })
        pageColumn.addView(speedCard, matchWrap())

        // 5. Generate, Play/Stop, and Save Audio
        pageColumn.addView(sectionTitle("5. Generate, Play & Save Audio"))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, 0)
        }

        val generateBtn = actionButton("✨   Generate Audio", blue)
        generateBtn.setOnClickListener { generateNewAudioAlwaysReplace() }
        actions.addView(generateBtn, matchWrap())

        playStopButton = actionButton("▶   Play Audio", green)
        playStopButton.setOnClickListener { togglePlayStopAudio() }
        actions.addView(playStopButton, matchWrap().apply { topMargin = dp(9) })

        val save = actionButton("↓   Save Audio", darkBlue)
        save.setOnClickListener { saveAudio() }
        actions.addView(save, matchWrap().apply { topMargin = dp(9) })
        pageColumn.addView(actions)

        val statusCard = card().apply { setPadding(dp(14), dp(13), dp(14), dp(13)) }
        status = TextView(this).apply {
            text = "Ready. Paste your Google AI Studio API Key above for real human voices."
            textSize = 13f
            setTextColor(ink)
        }
        statusCard.addView(status)
        val statusParams = matchWrap().apply { topMargin = dp(16) }
        pageColumn.addView(statusCard, statusParams)

        pageColumn.addView(createCopyrightFooter(), matchWrap().apply { topMargin = dp(14) })

        scroll.addView(pageColumn)
        setContentView(scroll)
        applySystemBarInsets(scroll)
    }

    private fun applyGenderAndEmotionTone() {
        if (!::speedBar.isInitialized || !::pitchBar.isInitialized) return
        val preset = emotions[selectedEmotionIndex.coerceIn(emotions.indices)]

        val basePitchProgress = when (selectedGenderFilter) {
            2 -> if (isBaseVoiceFemale()) 2 else 8
            1 -> if (isBaseVoiceFemale()) 10 else 13
            else -> 9
        }

        val targetSpeedProg = preset.speedProgress.coerceIn(0, 15)
        val targetPitchProg = if (selectedGenderFilter == 2 && isBaseVoiceFemale()) {
            (basePitchProgress + preset.pitchOffsetSteps).coerceIn(1, 4)
        } else {
            (basePitchProgress + preset.pitchOffsetSteps).coerceIn(0, 14)
        }

        speedBar.progress = targetSpeedProg
        pitchBar.progress = targetPitchProg
    }

    // ==================== UI HELPERS & ENGINE ROUTING ====================
    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ink)
        setPadding(dp(2), dp(20), dp(2), dp(9))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = rounded(Color.WHITE, 18, border)
    }

    private fun actionButton(value: String, color: Int) = Button(this).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        minHeight = dp(52)
        elevation = dp(2).toFloat()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    // Targeting SDK 35 forces edge-to-edge on Android 15: keep content clear of system bars / keyboard.
    // Below API 30 the window is not edge-to-edge, so no extra padding is needed.
    private fun applySystemBarInsets(v: View) {
        v.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                view.setPadding(i.left, i.top, i.right, i.bottom)
            }
            insets
        }
        v.requestApplyInsets()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { if (::status.isInitialized) runOnUiThread { status.text = message } }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ready = true
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    if (!isSavingMultiChunk) {
                        val feelName = emotions[selectedEmotionIndex].title.substringBefore(" ·")
                        val gLabel = when (selectedGenderFilter) {
                            1 -> "Female"
                            2 -> "Male"
                            else -> "Standard"
                        }
                        setStatus("Speaking Offline ($gLabel · $feelName)…")
                    }
                }
                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        if (isSavingMultiChunk) {
                            processNextSaveChunk()
                        } else if (speechQueue.isNotEmpty()) {
                            playNextSpeechChunk()
                        } else {
                            setStatus("Finished playing.")
                        }
                    }
                }
                override fun onError(utteranceId: String?) {
                    runOnUiThread {
                        speechQueue.clear()
                        isSavingMultiChunk = false
                        pendingSaveUri = null
                        tempChunkFiles.forEach { it.delete() }
                        tempChunkFiles.clear()
                        setStatus("Offline speech failed. Paste Google AI Studio API Key above for real voices.")
                    }
                }
            })
            refreshVoices()
        } else {
            refreshVoices()
        }
    }

    private fun selectedLanguageName(): String {
        val idx = if (::languageSpinner.isInitialized) languageSpinner.selectedItemPosition else 0
        return languages[idx.coerceIn(languages.indices)].shortName
    }

    private fun refreshVoices() {
        if (!isDeviceActivated() || !::voiceSpinner.isInitialized) return

        val keepStudioId = activeStudioVoices.getOrNull(voiceSpinner.selectedItemPosition)?.id
        val keepLocalName = localVoices.getOrNull(voiceSpinner.selectedItemPosition)?.name

        if (isApiKeyActive && apiKey.isNotEmpty()) {
            activeStudioVoices = when (selectedGenderFilter) {
                1 -> studioVoices.filter { it.gender == "Female" }
                2 -> studioVoices.filter { it.gender == "Male" }
                else -> studioVoices
            }
            voiceSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                activeStudioVoices.map { it.displayName }
            )
            keepStudioId?.let { id ->
                val i = activeStudioVoices.indexOfFirst { it.id == id }
                if (i >= 0) voiceSpinner.setSelection(i)
            }
            setStatus("Google AI Studio Active · ${selectedLanguageName()} (${activeStudioVoices.size} real voices)")
            return
        }

        if (!ready) return
        val allVoices = tts.voices?.toList() ?: emptyList()
        val langVoices = allVoices.filter { v ->
            val vLang = v.locale.language.lowercase(Locale.US)
            val targetLang = selectedLocale.language.lowercase(Locale.US)
            val countryMatch = selectedLocale.country.isEmpty() ||
                v.locale.country.equals(selectedLocale.country, ignoreCase = true) ||
                allVoices.none { it.locale.language.equals(targetLang, true) && it.locale.country.equals(selectedLocale.country, true) }
            vLang == targetLang && countryMatch
        }.sortedWith(compareBy<Voice> { it.isNetworkConnectionRequired }.thenBy { it.name })

        val filtered = when (selectedGenderFilter) {
            1 -> langVoices.filter { detectVoiceGender(it) == "Female" }
            2 -> langVoices.filter { detectVoiceGender(it) == "Male" }
            else -> langVoices
        }

        localVoices = if (filtered.isNotEmpty()) filtered else langVoices

        val labels = if (localVoices.isEmpty()) {
            listOf("Offline default voice · paste API Key for real voices")
        } else {
            localVoices.map { v ->
                val detected = detectVoiceGender(v)
                val displayTag = if (selectedGenderFilter == 2 && detected != "Male") {
                    "Offline Male Tone (Pitch-Adapted)"
                } else {
                    "Offline $detected"
                }
                "$displayTag · ${v.name}"
            }
        }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        keepLocalName?.let { n ->
            val i = localVoices.indexOfFirst { it.name == n }
            if (i >= 0) voiceSpinner.setSelection(i)
        }
        val genderMissing = selectedGenderFilter != 0 && filtered.isEmpty() && langVoices.isNotEmpty()
        val genderNote = if (genderMissing) {
            val g = if (selectedGenderFilter == 1) "female" else "male"
            " No installed $g voice for this language — using the available voice" +
                (if (selectedGenderFilter == 2) " with a lower pitch." else ".")
        } else ""
        val available = tts.isLanguageAvailable(selectedLocale)
        val langName = selectedLanguageName()
        if (available < TextToSpeech.LANG_AVAILABLE) {
            setStatus("Offline $langName not installed. Paste Google AI Studio API Key above to speak $langName immediately!")
        } else {
            tts.language = selectedLocale
            val sel = voiceSpinner.selectedItemPosition
            if (localVoices.isNotEmpty()) tts.voice = localVoices.getOrNull(sel) ?: localVoices.first()
            setStatus("Offline $langName ready (Paste API Key above for real human voices).$genderNote")
        }
    }

    private fun prepareLocalVoiceBase(): Boolean {
        if (!ready) { setStatus("Offline speech engine not ready. Paste API Key above."); return false }
        val result = tts.setLanguage(selectedLocale)
        if (result < TextToSpeech.LANG_AVAILABLE) {
            setStatus("Offline ${selectedLanguageName()} not installed. Paste Google AI Studio API Key above!")
            return false
        }
        if (localVoices.isNotEmpty() && voiceSpinner.selectedItemPosition in localVoices.indices) {
            tts.voice = localVoices[voiceSpinner.selectedItemPosition]
        }
        return true
    }

    private fun generateNewAudioAlwaysReplace() {
        val text = textInput.text.toString().trim()
        if (text.isEmpty()) { setStatus("Please enter some text first."); return }

        // Stop any current playback and delete old voice file
        deleteOldGeneratedAudio()
        if (ready) tts.stop()

        if (isApiKeyActive && apiKey.isNotEmpty()) {
            generateStudioAudio(text, saveToUri = null)
            return
        }

        // Offline fallback: synthesize directly into current_generated_voice.wav (replacing old audio) and auto-play
        if (!prepareLocalVoiceBase()) return
        speechQueue.clear()
        tempChunkFiles.forEach { it.delete() }
        tempChunkFiles.clear()

        pendingSaveUri = Uri.fromFile(getActiveAudioFile())
        pendingSignature = selectionSignature(text)
        isSavingMultiChunk = true
        speechQueue.addAll(buildExpressiveChunks(text))
        setStatus("Generating new offline audio — replacing old voice…")
        processNextSaveChunk()
    }

    private fun togglePlayStopAudio() {
        // If currently playing -> Stop
        if (isPlayingNow || (mediaPlayer?.isPlaying == true)) {
            stopMediaPlayer()
            speechQueue.clear()
            if (ready) tts.stop()
            updatePlayStopButtonUi(false)
            setStatus("Playback stopped.")
            return
        }

        // Otherwise play the current generated audio file
        val activeFile = getActiveAudioFile()
        if (isCachedAudioCurrent(textInput.text.toString())) {
            val label = if (isApiKeyActive) {
                val v = activeStudioVoices.getOrNull(voiceSpinner.selectedItemPosition) ?: activeStudioVoices.first()
                "${v.id} · ${v.gender}"
            } else {
                selectedLanguageName()
            }
            playWavFile(activeFile, label)
        } else {
            // If no audio has been generated yet, generate it now
            generateNewAudioAlwaysReplace()
        }
    }

    private fun playNextSpeechChunk(isFirst: Boolean = false) {
        val chunk = speechQueue.removeFirstOrNull() ?: return
        tts.setSpeechRate(chunk.rate)
        tts.setPitch(chunk.pitch)
        if (!isFirst && chunk.pauseAfterMs > 0L) {
            tts.playSilentUtterance(chunk.pauseAfterMs, TextToSpeech.QUEUE_ADD, "pause-${UUID.randomUUID()}")
        }
        val mode = if (isFirst) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts.speak(chunk.text, mode, null, "chunk-${UUID.randomUUID()}")
    }

    private fun saveAudio() {
        val activeFile = getActiveAudioFile()
        val text = textInput.text.toString().trim()
        val cachedOk = isCachedAudioCurrent(text)
        if (!cachedOk && text.isEmpty()) {
            setStatus("Please enter text and tap 'Generate Audio' first.")
            return
        }
        if (!cachedOk && !isApiKeyActive && !prepareLocalVoiceBase()) return

        val feelSlug = emotions[selectedEmotionIndex].title.substringBefore(" ").lowercase(Locale.US)
        val genderSlug = when (selectedGenderFilter) {
            1 -> "female"
            2 -> "male"
            else -> "voice"
        }
        val langSlug = selectedLocale.language.lowercase(Locale.US)
        val prefix = if (isApiKeyActive) "StudioVoice" else "TextToVoice"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "$prefix-$langSlug-$genderSlug-$feelSlug-${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(intent, 44)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            val destUri = data.data ?: return
            val activeFile = getActiveAudioFile()

            // Export the existing file only if it was made with the current voice choices
            if (isCachedAudioCurrent(textInput.text.toString())) {
                try {
                    contentResolver.openOutputStream(destUri)?.use { out ->
                        activeFile.inputStream().use { inp -> inp.copyTo(out) }
                    } ?: throw IllegalStateException("Cannot open destination file")
                    setStatus("Audio saved successfully!")
                } catch (e: Exception) {
                    setStatus("Save error: ${e.message ?: "unknown error"}")
                }
                return
            }

            // Otherwise generate first and save directly to destUri
            val text = textInput.text.toString().trim()
            if (text.isEmpty()) return

            if (isApiKeyActive && apiKey.isNotEmpty()) {
                generateStudioAudio(text, saveToUri = destUri)
                return
            }

            if (!prepareLocalVoiceBase()) return
            tts.stop()
            speechQueue.clear()
            tempChunkFiles.forEach { it.delete() }
            tempChunkFiles.clear()

            pendingSaveUri = destUri
            isSavingMultiChunk = true
            speechQueue.addAll(buildExpressiveChunks(text))
            setStatus("Generating audio file…")
            processNextSaveChunk()
        }
    }

    private fun processNextSaveChunk() {
        val chunk = speechQueue.removeFirstOrNull()
        if (chunk != null) {
            val chunkFile = File(cacheDir, "chunk-${tempChunkFiles.size}-${System.currentTimeMillis()}.wav")
            tempChunkFiles.add(chunkFile)
            tts.setSpeechRate(chunk.rate)
            tts.setPitch(chunk.pitch)
            val res = tts.synthesizeToFile(chunk.text, Bundle(), chunkFile, "savechunk-${UUID.randomUUID()}")
            if (res != TextToSpeech.SUCCESS) {
                isSavingMultiChunk = false
                speechQueue.clear()
                setStatus("Could not synthesize audio chunk.")
            }
        } else {
            isSavingMultiChunk = false
            val uri = pendingSaveUri
            pendingSaveUri = null
            if (uri != null) {
                try {
                    if (uri.scheme == "file" && uri.path != null) {
                        val targetFile = File(uri.path!!)
                        mergeWavFilesToFile(tempChunkFiles, targetFile)
                        lastAiAudioFile = targetFile
                        lastAiCacheSignature = pendingSignature
                        playWavFile(targetFile, selectedLanguageName())
                    } else {
                        mergeWavFilesToUri(tempChunkFiles, uri)
                        setStatus("Audio saved successfully!")
                    }
                } catch (e: Exception) {
                    setStatus("Could not process audio: ${e.message ?: "unknown error"}")
                } finally {
                    tempChunkFiles.forEach { it.delete() }
                    tempChunkFiles.clear()
                }
            }
        }
    }

    private fun mergeWavFilesToFile(wavFiles: List<File>, destFile: File) {
        if (destFile.exists()) destFile.delete()
        mergeWavFilesToUri(wavFiles, Uri.fromFile(destFile))
    }

    private fun mergeWavFilesToUri(wavFiles: List<File>, destUri: Uri) {
        if (wavFiles.isEmpty()) throw IllegalStateException("No audio generated")
        if (wavFiles.size == 1) {
            contentResolver.openOutputStream(destUri)?.use { out ->
                wavFiles[0].inputStream().use { inp -> inp.copyTo(out) }
            }
            return
        }

        val pcmStream = ByteArrayOutputStream()
        var sampleRate = 22050
        var numChannels = 1
        var bitsPerSample = 16

        for ((idx, f) in wavFiles.withIndex()) {
            if (!f.exists() || f.length() <= 44) continue
            val bytes = f.readBytes()
            if (idx == 0 && bytes.size >= 44) {
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                numChannels = bb.getShort(22).toInt()
                sampleRate = bb.getInt(24)
                bitsPerSample = bb.getShort(34).toInt()
            }
            var offset = 12
            while (offset + 8 <= bytes.size) {
                val id = String(bytes, offset, 4, Charsets.US_ASCII)
                val size = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (id == "data") {
                    val dataStart = offset + 8
                    val dataLen = size.coerceAtMost(bytes.size - dataStart).coerceAtLeast(0)
                    pcmStream.write(bytes, dataStart, dataLen)
                    val pauseMs = emotions[selectedEmotionIndex].sentencePauseMs
                    val bytesPerSec = sampleRate * numChannels * (bitsPerSample / 8)
                    val silenceBytes = ((bytesPerSec * pauseMs) / 1000L).toInt() and 0x7FFFFFFE
                    if (silenceBytes > 0) {
                        pcmStream.write(ByteArray(silenceBytes))
                    }
                    break
                }
                offset += 8 + size
            }
        }

        val totalPcm = pcmStream.toByteArray()
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)
        val blockAlign = (numChannels * (bitsPerSample / 8)).toShort()
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(36 + totalPcm.size)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1)
            putShort(numChannels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign)
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(totalPcm.size)
        }.array()

        contentResolver.openOutputStream(destUri)?.use { out ->
            out.write(header)
            out.write(totalPcm)
        } ?: throw IllegalStateException("Could not open destination file")
    }

    override fun onPause() {
        saveUserWork()
        super.onPause()
    }

    override fun onDestroy() {
        saveUserWork()
        stopMediaPlayer()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
